
  <div class="row">
   
    <div class="col-xs-12">
        
    <?php
if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; }; 
$num_rec_per_page=30;
$start_from = ($page-1) * $num_rec_per_page; 	
if (isset($_POST['ok'])) {
$search = addslashes($_POST['search']);
$total_records = mysql_num_rows(mysql_query("SELECT * FROM lichsumua where name like '%$search%'"));  //count number of records
}else{
$total_records = mysql_num_rows(mysql_query("SELECT * FROM lichsumua"));  //count number of records
}
$total_pages = ceil($total_records / $num_rec_per_page); 
?>
      <div class="panel panel-default">
  <div class="panel-heading">Lịch Sử Mua</div>
  <div class="panel-body">
        
        <div class="card-body no-padding">
          <table class="datatable table table-striped primary" cellspacing="0" width="100%">

<table class="table table-striped table-vcenter">
                                <thead>
                                    <tr>
                                        <th>Tài khoản</th>
                                        <th>UID</th>
                                        <th>Tín dụng</th>
                                        <th>ID ACC</th>
                                        <th>Ngày mua</th>
                                    </tr>
                                </thead>
                                <tbody>


<?php
if (isset($_POST['ok'])) {
$search = addslashes($_POST['search']);
$cash = mysql_query("SELECT * FROM `lichsumua` where name like '%$search%' order by id desc LIMIT $start_from, $num_rec_per_page");
}else{
$cash = mysql_query("SELECT * FROM `lichsumua` order by id desc LIMIT $start_from, $num_rec_per_page");
}
if (mysql_num_rows($cash) == 0):
?>
<tr><td colspan="5" class="text-center"><p>Chưa có ai mua</p></td></tr>
<?php else: while ($row = mysql_fetch_array($cash, MYSQL_ASSOC)):?>

<tr >
  <td class="text-muted"><a href="http://facebook.com/<?=$row['uid']?>"><?=$row['name']?></a></span>
 <td class="text-primary"><?=$row['uid']?></td> 
 </td>
<td class="font-w600 text-success">- <?=number_format($row['price'])?> <sup class="text-muted">vnđ</sup></td>
 <td class="text-primary"><?=$row['loainick']?> #<?=$row['idacc']?></td> 
 <td class="text-primary"><?=$row['date']?></td> 
</tr >
  <?php $i++; endwhile; endif; ?>   

                                 
                                                              </tbody>
</table>

      

<ul class="pagination">


<?
echo "<li class=''><a href='?act=lsmua&page=1'>".'Trang đầu'."</a> </li>"; // Goto 1st page  

for ($i=1; $i<=$total_pages; $i++) { 
            echo "<li class=''><a href='?act=lsmua&page=".$i."'>".$i."</a></li>"; 
}; 
echo "<li class=''><a href='?act=lsmua&page=$total_pages'>".'Trang cuối'."</a></li>";

?>
 



    </ul>

