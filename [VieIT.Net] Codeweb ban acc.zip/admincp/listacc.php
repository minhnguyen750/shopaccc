  <div class="row">  

    <div class="col-xs-12">

<?php 

   


if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; }; 
$num_rec_per_page=30;
$start_from = ($page-1) * $num_rec_per_page; 	

$total_records = mysql_num_rows(mysql_query("SELECT * FROM baidang"));  //count number of records

$total_pages = ceil($total_records / $num_rec_per_page); 
		?>
<div class="panel panel-default">
  <div class="panel-heading">Danh Sách Account</div>
  <div class="panel-body">
             <div class="col-xs-6"> Danh Sách Acc</div> 
     
        
        <div class="card-body no-padding">
          <table class="datatable table table-striped primary" cellspacing="0" width="100%">

<table class="table table-striped table-vcenter">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Tài Khoản</th>
                                        <th>Mật khẩu</th>
                                        <th>Giá</th>
                                    </tr>
                                </thead>
                                <tbody>

     

<?php

$cash = mysql_query("SELECT * FROM `baidang` order by id LIMIT $start_from, $num_rec_per_page");

if (mysql_num_rows($cash) == 0):
?>
<tr><td colspan="5" class="text-center"><p>Không có tài khoản nào</p></td></tr>
<?php else: while ($row = mysql_fetch_array($cash, MYSQL_ASSOC)):?>

<tr >
<td class="text-muted">

<?=$row['id']?>
 </td><td class="text-muted">
<?=$row['taikhoan']?>

 </td>
 <td class="text-primary"><?=$row['matkhau']?></td> 




<td class="font-w600 text-success"><?=number_format($row['gia'])?> <sup class="text-muted">vnđ</sup></td>







  <?php $i++; endwhile; endif; ?>  

                                 
                                  </tbody>
</table>

      
      <ul class="pagination">


<?
echo "<li class=''><a href='?act=listacc&page=1'>".'Trang đầu'."</a> </li>"; // Goto 1st page  

for ($i=1; $i<=$total_pages; $i++) { 
            echo "<li class=''><a href='?act=listacc&page=".$i."'>".$i."</a></li>"; 
}; 
echo "<li class=''><a href='?act=listacc&page=$total_pages'>".'Trang cuối'."</a></li>";

?>
 



    </ul>


