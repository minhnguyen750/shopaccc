<?php

//* admin user *///
if (isset($_GET['unadmin'])) {
mysql_query("UPDATE `nguoidung` SET `admin` = '0' where `uid`='".$_GET['uid']."'");
echo'<div class="alert alert-success" role="alert">
  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
  <span class="sr-only">Thông báo:</span> Xuống Menber cho UID '.$_GET['uid'].' thành công!
</div>';
}elseif (isset($_GET['admin'])) {
mysql_query("UPDATE `nguoidung` SET `admin` = '100' where `uid`='".$_GET['uid']."'");
echo'<div class="alert alert-success" role="alert">
  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
  <span class="sr-only">Thông báo:</span> Lên Admin UID '.$_GET['uid'].' thành công!
</div>';
}
   


if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; }; 
$num_rec_per_page=30;
$start_from = ($page-1) * $num_rec_per_page; 	
if (isset($_POST['ok'])) {
$search = addslashes($_POST['search']);
$total_records = mysql_num_rows(mysql_query("SELECT * FROM nguoidung where hovaten like '%$search%'"));  //count number of records
}else{
$total_records = mysql_num_rows(mysql_query("SELECT * FROM nguoidung"));  //count number of records
}
$total_pages = ceil($total_records / $num_rec_per_page); 
		?>
 

<table class="table table-striped table-vcenter">
                                <thead>
                                    <tr>
                                        <th>Tài khoản</th>
                                        <th>UID</th>
                                        <th>Thao tác</th>
                                    </tr>
                                </thead>
                                <tbody>

<tr><td colspan="5" class="text-center"><form action ="?act=lenadmin" method="POST">
  <div class="input-group">
    <input type="text" class="form-control" placeholder="Nhập tên thành viên" name="search">
    <div class="input-group-btn">
      <button class="btn btn-default" type="submit" name="ok">
        <i class="glyphicon glyphicon-search"></i>
      </button>
    </div>
  </div>
</form></td></tr>
<?php
if (isset($_POST['ok'])) {
$search = addslashes($_POST['search']);
$cash = mysql_query("SELECT * FROM `nguoidung` where hovaten like '%$search%' order by id LIMIT $start_from, $num_rec_per_page");
}else{
$cash = mysql_query("SELECT * FROM `nguoidung` order by id LIMIT $start_from, $num_rec_per_page");
}
if (mysql_num_rows($cash) == 0):
?>
<tr><td colspan="5" class="text-center"><p>Chưa có người dùng</p></td></tr>
<?php else: while ($row = mysql_fetch_array($cash, MYSQL_ASSOC)):?>

<tr >
<td class="text-muted">
<?php if($row['ban'] < 1): ?>
<a href="http://facebook.com/<?=$row['uid']?>"><?=$row['hovaten']?></a>
<?php else: ?>
<a href="http://facebook.com/<?=$row['uid']?>" style="text-decoration: line-through; color: #000; font-weight: bold;"><?=$row['hovaten']?></a>
<?php endif; ?>
</span>
 <td class="text-primary"><?=$row['uid']?></td> 

<td class="font-w600 text-success">

 <?php if($row['admin'] < 100): ?>
<a href="?act=lenadmin&uid=<?=$row['uid']?>&admin" class="label label-success">Admin</a></td>
<?php else: ?>
<a href="?act=lenadmin&uid=<?=$row['uid']?>&unadmin" class="label label-success">Menber </a></td>
<?php endif; ?>


  <?php $i++; endwhile; endif; ?>  

                                 
                                </tbody>
                            </table>



<ul class="pagination">


<?
echo "<li class=''><a href='?act=member&page=1'>".'Trang đầu'."</a> </li>"; // Goto 1st page  

for ($i=1; $i<=$total_pages; $i++) { 
            echo "<li class=''><a href='?act=member&page=".$i."'>".$i."</a></li>"; 
}; 
echo "<li class=''><a href='?act=member&page=$total_pages'>".'Trang cuối'."</a></li>";

?>
 



    </ul>

</div></div></div>