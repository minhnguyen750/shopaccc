<?php
if(isset($_GET['okres'])):
mysql_query("TRUNCATE TABLE top");
?>
<div class="alert alert-danger" role="alert">
  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
  <span class="sr-only">Thông báo:</span> Đã reset top nạp thẻ thành công!
</div>
<?php endif; ?>

<div class="panel panel-default">
  <div class="panel-heading">Reset top nạp thẻ</div>
  <div class="panel-body">Bạn có muốn reset top nạp thẻ lần này không?</div>
  <div class="panel-footer"><a href="?act=restop&okres"><button class="btn btn-danger btn-sm" type="button">Xác nhận</button></a> <a href="/acp"><button class="btn btn-default btn-sm" type="button">Hủy</button></a></div>
</div>