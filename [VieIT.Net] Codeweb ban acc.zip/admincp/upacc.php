<?php
if(isset($_POST['upacc'])):

	if(!isset($_POST['giamgia'],$_POST['gia'],$_POST['idpassword'],$_POST['bangngoc'],$_POST['anhthongtin'],$_POST['anhngoc'],$_POST['noidung'])){
	echo'<div class="alert alert-danger">Chưa nhập đầy đủ thông tin cần thiết, hãy <a href="javascript: history.go(-1)" class="alert-link">thử lại</a></div>';
	}elseif(!$_POST['gia'] || !$_POST['idpassword'] || !$_POST['bangngoc'] || !$_POST['anhthongtin'] || !$_POST['anhngoc'] || !$_POST['noidung']){
	echo'<div class="alert alert-danger">Bạn chưa nhập đầy đủ thông tin cần thiết, hãy <a href="javascript: history.go(-1)" class="alert-link">thử lại</a></div>';
}else{


$idpassword = explode(":",$_POST['idpassword']);
$giamgia = $_POST['giamgia'];
$rank = $_POST['rank'];
$khung = $_POST['khung'];
$hinhanh = $_POST['anhthongtin'];
$bangngoc = $_POST['bangngoc'];
$thongtin = $_POST['thongtin'];
$noidung = $_POST['noidung'];
$thumb = explode("|",$_POST['anhthongtin']);
$anhbangngoc = $_POST['anhngoc'];
$active = (isset($_POST['active'])) ? "yes" : "no";
$price = $_POST['gia'];
$price_atm = $_POST['atm'];
$price -= ($_POST['giamgia'] / 100) * $_POST['gia'];

mysql_query("INSERT INTO `baidang` SET
`loainick` = '". $_POST['loainick'] ."',
`taikhoan` = '". $idpassword[0] ."' ,
`matkhau` = '". $idpassword[1] ."',
`champs` = '".addslashes($_POST['champs'])."',
`skins` = '".addslashes($_POST['skins'])."',
`rank` = '" . $rank . "',
`noidung` = '" . mysql_real_escape_string($noidung) . "',
`thongtin` = '" . mysql_real_escape_string($thongtin) . "',
`hinhanh` = '" . $hinhanh . "',
`thumb` = '". $thumb[0] ."',
`gia` = '" . $price . "',
`atm` = '" . $price_atm . "',
`giacu` = '" . $_POST['gia'] . "',
`giamgia` = '" . $giamgia . "',
`trangthai` = 'on',
`bangngoc` = '" . $anhbangngoc . "',
`kichhoat` = '" . $active . "',
`count_bangngoc` = '" . $bangngoc . "',
`count_skin` = '".$_POST['count_skin']."',
`count_champ` = '".$_POST['count_champ']."',
`khung` = '" . $khung . "',
`time` = '" . time() . "'
");



echo'<div class="alert alert-success" role="alert">
  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
  <span class="sr-only">Thông báo:</span>Thành công
</div>';

}

endif;

?>

<div class="panel panel-default">
  <div class="panel-heading">Thêm tài khoản</div>
  <div class="panel-body">


<form action ="?act=upacc" method="post" enctype="multipart/form-data">


	<div class="row">
	<div class="col-md-4">
	    <div class="form-group">
	        <div class="input-group">
	            <div class="input-group-addon">
	                Skin
	            </div><input class="form-control" type="file" name="fileToUpload" id="fileToUpload">        </div>
	    </div>
	</div>



	<div class="col-md-4">
	    <div class="form-group">
	        <div class="input-group">
	            <div class="input-group-addon">
	                Rank
	            </div>
<select class="form-control" name="rank">

<?php
for ($i = 0; $i < 29; $i++){
    echo '<option value="'.$i.'">'.get_string_rank($i).'</option>';
}
?>

</select>

</div></div></div>


           <div class="col-md-4">
	              <div class="form-group">
	                <div class="input-group">


	            <div class="input-group-addon">
	                Khung
	            </div>
<select class="form-control" name="khung">

<?php
for ($i = 0; $i < 7; $i++){
    echo '<option value="'.$i.'">'.get_string_khung($i).'</option>';
}
?>

</select>

	                </div>
	              </div>
	            </div> 
							</div>

	<div class="row">

	<div class="col-md-4">
	    <div class="form-group">
	                <label>Loại game</label>
	        <div class="input-group">
	            <div class="input-group-addon">
	                Game
	            </div>
	<select class="form-control" name="loainick" id="loainick">


	                <option value="LQ">
	                    Liên Quân 
	                </option>
	            </select>
	        </div>
	    </div>
	</div>


							<div class="col-md-4">
	              <div class="form-group">
	                <label>Giá</label>
	                <input class="form-control" placeholder="Giá" name="gia" type="number" autofocus="" value="">
	              </div>
	            </div>
	            <div class="col-md-4">
	              <div class="form-group">
	                <label>Khuyễn mãi</label>
	                <div class="input-group">
	                  <input class="form-control" placeholder="Khuyễn mãi" name="giamgia" type="number" maxlength="3" value="">
	                  <div class="input-group-addon">%</div>
	                </div>
	              </div>
	            </div>
	            <div class="col-md-12">
	              <div class="form-group">
	                <label>Thông tin đăng nhập</label>
	                <input class="form-control" placeholder="tài khoản:mật khẩu" id="idpassword" name="idpassword" type="text" value=""
	              </div>
	            </div>
	          </div>

	          
	            <div class="col-md-2">
	<div class="form-group">
	                <label>Số bảng ngọc</label>
	                <input class="form-control" placeholder="Số bảng ngọc" id="bangngoc" name="bangngoc" type="text" value="">
	              </div>
	            </div>
             
	            <div class="col-md-2">
	                <div class="form-group">
	                <label>Số tướng</label>
	                <input class="form-control" placeholder="Số tướng" id="" name="count_champ" type="text" value="">
	              </div>
	            </div>
	          <div class="row">
	            <div class="col-md-2">
	<div class="form-group">
	                <label>Số skin</label>
	                <input class="form-control" placeholder="Số trang phục" id="" name="count_skin" type="text" value="">
	              </div>
	            </div>
	          </div>
	          
	         <div class="col-md-4">
	              <div class="form-group">
	                <label>Giá ATM</label>
	                <input class="form-control" placeholder="Giá" name="atm" type="number" autofocus="" value="">
	              </div>
	            </div> 
	          
	          <div class="row">
	            <div class="col-md-12">
	              <div class="form-group">
	                <label>Hình ảnh thông tin</label>
	                <textarea class="form-control" rows="2" name="anhthongtin" placeholder="Url hình ảnh|Url hình ảnh|url hình ảnh"><?=$get['hinhanh']?></textarea>
	              </div>
	            </div>
	          </div>
	          
	          <div class="row">
	            <div class="col-md-12">
	              <div class="form-group">
	                <label>Hình ảnh ngọc</label>
	                <textarea class="form-control" rows="2" name="anhngoc" placeholder="Url hình ảnh|Url hình ảnh|url hình ảnh"><?=$get['bangngoc']?></textarea>
	              </div>
	            </div>
	          </div>

	          <div class="row">
	            <div class="col-md-12">
	               <div class="form-group">
	                <label>Nội Dung</label>
	                <textarea class="form-control" rows="3" name="noidung" placeholder="Cái này nhập tầm bậy cũng đc"></textarea>
	              </div>
	            </div>
	          </div>
	          
	          <div class="row">
	            <div class="col-md-12">
	               <div class="form-group">
	                <label>Thông Tin</label>
	                <textarea class="form-control" rows="3" name="thongtin" placeholder="Còn cái này nhập vào nó sẽ hiển thị bên ngoài acc"></textarea>
	              </div>
	            </div>
	          </div>
	          
          <div class="row">
            <div class="col-md-6">
              <div class="form-group remove-margin-b">
                <label class="css-input switch switch-sm switch-primary">
                  <input type="checkbox" id="active" name="active" checked="true"><span></span> Kích hoạt?
                </label>
              </div>
            </div></div>

	            
	          <div class="row">
	            <div class="col-md-12">
	              <div class="form-group">
	<button id="login" type="submit" class="sa-lib-dk btn btn-success" name="upacc">Đăng bán</button>

	              </div>
	            </div>
	          </div>





</div>
</div>