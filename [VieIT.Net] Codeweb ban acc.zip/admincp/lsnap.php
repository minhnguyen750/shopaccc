
  <div class="row">
   
    <div class="col-xs-12">
        
    <?php
    if(isset($_GET['menhgia'])){
        $mysql = mysql_fetch_assoc(mysql_query("SELECT * FROM `lichsunap` WHERE `id` = '".$_POST['id']."' "));
        if($mysql['status'] == 1){
            mysql_query("UPDATE `lichsunap` SET `status` = '0',`note` = 'Sai mệnh giá. Mệnh giá thật ".$_POST['amount']."' where `id`='".$_POST['id']."'");
    
            
        mysql_query("UPDATE `nguoidung` SET `cash` = `cash` + '".($_POST['amount'] * 90 / 100)."' where `uid`='".$mysql['uid']."'");
        
        echo 'Duyệt thành công '.$_POST['id'];
        
        die();
        
    }
    
    }
    
    if (isset($_GET['allow'])) {
    
    $mysql = mysql_fetch_assoc(mysql_query("SELECT * FROM `lichsunap` WHERE `id` = '".$_GET['trans']."' "));
    if($mysql['status'] == 1){
        mysql_query("UPDATE `lichsunap` SET `status` = '0',`note` = 'Đã duyệt' where `id`='".$_GET['trans']."'");

        
    mysql_query("UPDATE `nguoidung` SET `cash` = `cash` + '".($mysql['menhgia'] * 90 / 100)."' where `uid`='".$mysql['uid']."'");
    
    echo'<div class="alert alert-success" role="alert">
      <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
      <span class="sr-only">Thông báo:</span> đã duyệt # '.$_GET['trans'].' thành công!
    </div>';
    }
    }elseif (isset($_GET['deni'])) {
    mysql_query("UPDATE `lichsunap` SET `status` = '2',`note` = 'Bị từ chối' where `id`='".$_GET['trans']."'");
    echo'<div class="alert alert-success" role="alert">
      <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
      <span class="sr-only">Thông báo:</span> Đã từ chối # '.$_GET['trans'].' thành công!
    </div>';
    }
    
if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; }; 
$num_rec_per_page=30;
$start_from = ($page-1) * $num_rec_per_page; 	
if (isset($_POST['ok'])) {
$search = addslashes($_POST['search']);
$total_records = mysql_num_rows(mysql_query("SELECT * FROM lichsunap where name like '%$search%'"));  //count number of records
}else{
$total_records = mysql_num_rows(mysql_query("SELECT * FROM lichsunap"));  //count number of records
}
$total_pages = ceil($total_records / $num_rec_per_page); 
?>
 
  <div class="panel panel-default">
  <div class="panel-heading">Lịch Sử Nạp</div>
  <div class="panel-body">
             <div class="col-xs-10"> Lịch Sử Nạp Thẻ</div>   <div class="col-xs-3"> <form action ="?act=lsnap" method="POST">
  <div class="input-group">
    <input type="text" class="form-control" placeholder="Nhập tên thành viên" name="search">
    <div class="input-group-btn">
      <button class="btn btn-default" type="submit" name="ok">
        <i class="fa fa-search"></i>
      </button>
    </div>
  </div>
</form></div>
      
        
        <div class="card-body no-padding">
          <table class="datatable table  table-striped primary" cellspacing="0" width="100%">
              
<table class="table table-striped  table-vcenter">
                                <thead>
                                    <tr>
                                        <th>Tài khoản</th>
                                        <th>UID</th>
                                        <th>Loại</th>
                                        <th>Mệnh giá</th>
                                        <th>Loại thẻ/mã</th>
                                        <th>Ngày nạp</th>
                                        <th>Trạng thái</th>
                                        <th>Hành động</th>
                                    </tr>
                                </thead>
                                <tbody>
               
<?php
if (isset($_POST['ok'])) {
$search = addslashes($_POST['search']);
$cash = mysql_query("SELECT * FROM `lichsunap` where name like '%$search%' order by id desc LIMIT $start_from, $num_rec_per_page");
}else{
$cash = mysql_query("SELECT * FROM `lichsunap` order by id desc LIMIT $start_from, $num_rec_per_page");
}
if (mysql_num_rows($cash) == 0):
?>
<tr><td colspan="8" class="text-center"><p>Chưa có ai nạp</p></td></tr>
<?php else: while ($row = mysql_fetch_array($cash, MYSQL_ASSOC)):?>


<?php

$ten = mysql_fetch_assoc(mysql_query("SELECT * FROM `nguoidung` WHERE `uid` = '".$row['uid']."'"));
?>

<tr >
  <td class="text-muted"><a href="http://facebook.com/<?=$row['uid']?>"><?=$row['name']?></a></span>
 <td class="text-primary"><?=$row['uid']?></td> 
 </td>
 <td><?=$row['loaithe']?></td>
<td class="font-w600 text-success"><?=number_format($row['menhgia'])?> <sup class="text-muted">vnđ</sup></td>
 <td class="text-primary"><?=$row['mathe']?>/<?=$row['serial']?></td> 
 <td class="text-primary"><?=$row['date']?></td> 
  <td class="text-primary"><?=$row['note']?></td> 
  <td>

<?php if($row['status'] == '1'): ?>
<a href="?act=lsnap&trans=<?=$row['id']?>&allow" class="label label-success"> Duyệt</a>
<a href="?act=lsnap&trans=<?=$row['id']?>&deni" class="label label-danger"> Hủy</a>
<?php endif; ?>

</td>

</tr >
  <?php $i++; endwhile; endif; ?>   

                                 
                                                                          </tbody>
</table>

       

<ul class="pagination">

<?
echo "<li class=''><a href='?act=lsnap&page=1'>".'Trang đầu'."</a> </li>"; // Goto 1st page  

for ($i=1; $i<=$total_pages; $i++) { 
            echo "<li class=''><a href='?act=lsnap&page=".$i."'>".$i."</a></li>"; 
}; 
echo "<li class=''><a href='?act=lsnap&page=$total_pages'>".'Trang cuối'."</a></li>";

?>
 


</ul>


<script>

function menhgia(id){
    var menhgia = prompt("Mệnh giá muốn duyệt cho giao dịch số"+id);
    var r = confirm("có chắc chắn duyệt mệnh giá"+ menhgia);
    if (r == true) {
    $.ajax({type: "POST",
    url: "?act=lsnap&menhgia",
    data: {
      id : id,
      amount: menhgia


        },
      success:function(result){

        alert('ok');


    }});
    }



    
}
    
</script>
