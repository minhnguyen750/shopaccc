<?php

    session_start();
    ob_start();
    
    # Tiêu đề trang 
    $headtitle = 'ACP';
    
    # Import Hệ thống
    require('../core/database.php');
    require('head.php');



    switch ($_GET['act']) {
    	case 'member':
    		require('thanhvien.php');
    		break;


case 'lenadmin':
    		require('lenadmin.php');
    		break;
        case 'listacc':
    		require('listacc.php');
    		break;

        case 'congtien':
    		require('congtien.php');
    		break;
     	case 'lsmua':
    		require('lsmua.php');
    		break; 
    	case 'restop':
    		require('restop.php');
    		break;
    	case 'lsnap':
    		require('lsnap.php');
    		break;
    	case 'upacc':
    		require('upacc.php');
    		break; 
    	case 'random':
    		require('random.php');
    		break; 
    	case 'edit':
    		require('edit.php');
    		break; 
    	case 'delete':
    		require('delete.php');
    		break;    	
    	
    }
    require('footer.php');

?>
  