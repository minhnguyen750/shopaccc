

    <div class="col-xs-12">
    <?php
//* ban user *///
if (isset($_GET['unban'])) {
mysql_query("UPDATE `nguoidung` SET `ban` = '1' where `uid`='".$_GET['uid']."'");
echo'<div class="alert alert-success" role="alert">
  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
  <span class="sr-only">Thông báo:</span> Hủy khóa cho UID '.$_GET['uid'].' thành công!
</div>';
}elseif (isset($_GET['ban'])) {
mysql_query("UPDATE `nguoidung` SET `ban` = '1' where `uid`='".$_GET['uid']."'");
echo'<div class="alert alert-success" role="alert">
  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
  <span class="sr-only">Thông báo:</span> Đã khóa UID '.$_GET['uid'].' thành công!
</div>';
}



//* admin user *///
if (isset($_GET['unadmin'])) {
mysql_query("UPDATE `nguoidung` SET `admin` = '1' where `uid`='".$_GET['uid']."'");
echo'<div class="alert alert-success" role="alert">
  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
  <span class="sr-only">Thông báo:</span> Xuống Menber cho UID '.$_GET['uid'].' thành công!
</div>';
}elseif (isset($_GET['admin'])) {
mysql_query("UPDATE `nguoidung` SET `admin` = '0' where `uid`='".$_GET['uid']."'");
echo'<div class="alert alert-success" role="alert">
  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
  <span class="sr-only">Thông báo:</span> Lên Admin UID '.$_GET['uid'].' thành công!
</div>';
}
   


if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; }; 
$num_rec_per_page=30;
$start_from = ($page-1) * $num_rec_per_page; 	
if (isset($_POST['ok'])) {
$search = addslashes($_POST['search']);
$total_records = mysql_num_rows(mysql_query("SELECT * FROM nguoidung where hovaten like '%$search%'"));  //count number of records
}else{
$total_records = mysql_num_rows(mysql_query("SELECT * FROM nguoidung"));  //count number of records
}
$total_pages = ceil($total_records / $num_rec_per_page); 
		?>
<div class="panel panel-default">
  <div class="panel-heading">List Thành Viên</div>
  <div class="panel-body">
             <div class="col-xs-6"> Thành Viên</div>   <div class="col-xs-3"> <form action ="?act=member" method="POST">
  <div class="input-group ">
    <input type="text" class="form-control" placeholder="Nhập tên thành viên" name="search">
    <div class="input-group-btn">
      <button class="btn btn-default " type="submit" name="ok">
        <i class="fa fa-search"></i>
      </button>
    </div>
  </div>
</form></div>
        
        <div class="card-body no-padding">
          <table class="datatable table table-striped primary" cellspacing="0" width="100%">

<table class="table table-striped table-vcenter">
                                <thead>
                                    <tr>
                                        <th>Tài khoản</th>
                                        <th>UID</th>
                                        <th>Tiền</th>
                                        <th>Chức Vụ</th>
                                        <th>Thao tác</th>
                                    </tr>
                                </thead>
                                <tbody>

     

<?php
if (isset($_POST['ok'])) {
$search = addslashes($_POST['search']);
$cash = mysql_query("SELECT * FROM `nguoidung` where hovaten like '%$search%' order by id LIMIT $start_from, $num_rec_per_page");
}else{
$cash = mysql_query("SELECT * FROM `nguoidung` order by id LIMIT $start_from, $num_rec_per_page");
}
if (mysql_num_rows($cash) == 0):
?>
<tr><td colspan="5" class="text-center"><p>Không có người dùng này</p></td></tr>
<?php else: while ($row = mysql_fetch_array($cash, MYSQL_ASSOC)):?>

<tr >
<td class="text-muted">
<?php if($row['ban'] < 1): ?>
<a href="http://facebook.com/<?=$row['uid']?>"><?=$row['hovaten']?></a>
<?php else: ?>
<a href="http://facebook.com/<?=$row['uid']?>" style="text-decoration: line-through; color: #000; font-weight: bold;"><?=$row['hovaten']?></a>
<?php endif; ?>
</span>
 <td class="text-primary"><?=$row['uid']?></td> 
 </td>



<td class="font-w600 text-success"><?=number_format($row['cash'])?> <sup class="text-muted">vnđ</sup></td>
<td class="font-w600 text-success"> <?php if($row['admin'] < 1): ?>
Thành Viên
<?php else: ?>
Admin
<?php endif; ?>
</td>
<td class="text-success"><a href="?act=congtien&uid=<?=$row['uid']?>" class="label label-success"> Cộng tiền</a> 
 <?php if($row['admin'] < 1): ?>
 <a href="?act=member&uid=<?=$row['uid']?>&admin" class="label label-success"> Admin</a>
<?php else: ?>
 <a href="?act=member&uid=<?=$row['uid']?>&unadmin" class="label label-success"> Member</a>
<?php endif; ?>

<?php if($row['ban'] < 1): ?>
<a href="?act=member&uid=<?=$row['uid']?>&ban" class="label label-danger"> Khóa</a></td>
<?php else: ?>
<a href="?act=member&uid=<?=$row['uid']?>&unban" class="label label-danger"> Mở Khóa</a></td>
<?php endif; ?>




  <?php $i++; endwhile; endif; ?>  

                                 
                                  </tbody>
</table>

     
      <ul class="pagination">


<?
echo "<li class=''><a href='?act=member&page=1'>".'Trang đầu'."</a> </li>"; // Goto 1st page  

for ($i=1; $i<=$total_pages; $i++) { 
            echo "<li class=''><a href='?act=member&page=".$i."'>".$i."</a></li>"; 
}; 
echo "<li class=''><a href='?act=member&page=$total_pages'>".'Trang cuối'."</a></li>";

?>
 



    </ul>


