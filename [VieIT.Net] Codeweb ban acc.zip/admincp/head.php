<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="https://wrappixel.com/demos/admin-templates/ampleadmin/plugins/images/favicon.png">
    <title>Bảng Điều Khiển</title>
    <!-- Bootstrap Core CSS -->
    <link href="bootstrap/dist/css/bootstrap.min.css?tuannguyen2811=<?=rand(1,10000)?>" rel="stylesheet">
    <!-- Menu CSS -->
    <link href="plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.css?tuannguyen2811=<?=rand(1,10000)?>" rel="stylesheet">
    <!-- toast CSS -->
    <link href="plugins/bower_components/toast-master/css/jquery.toast.css?tuannguyen2811=<?=rand(1,10000)?>" rel="stylesheet">
    <!-- morris CSS -->
    <link href="plugins/bower_components/morrisjs/morris.css?tuannguyen2811=<?=rand(1,10000)?>" rel="stylesheet">
    <!-- chartist CSS -->
    <link href="plugins/bower_components/chartist-js/dist/chartist.min.css?tuannguyen2811=<?=rand(1,10000)?>" rel="stylesheet">
    <link href="plugins/bower_components/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.css?tuannguyen2811=<?=rand(1,10000)?>" rel="stylesheet">
    <!-- animation CSS -->
    <link href="css/animate.css?tuannguyen2811=<?=rand(1,10000)?>" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css?tuannguyen2811=<?=rand(1,10000)?>" rel="stylesheet">
    <!-- color CSS -->
    <link href="css/colors/default.css?tuannguyen2811=<?=rand(1,10000)?>" id="theme" rel="stylesheet">
</head>


    <div id="wrapper">
        <nav class="navbar navbar-default navbar-static-top m-b-0">
            <div class="navbar-header">
                <div class="top-left-part">
                    <!-- Logo -->
                    <a class="logo" href="index.php">
                        <!-- Logo icon image, you can use font-icon also --><b>
                        <!--This is dark logo icon--><img src="https://wrappixel.com/demos/admin-templates/ampleadmin/plugins/images/admin-logo.png" alt="home" class="dark-logo" /><!--This is light logo icon--><img src="https://wrappixel.com/demos/admin-templates/ampleadmin/plugins/images/admin-logo-dark.png" alt="home" class="light-logo" />
                     </b>
                        <!-- Logo text image you can use text also --><span class="hidden-xs">
                        <!--This is dark logo text--><img src="https://wrappixel.com/demos/admin-templates/ampleadmin/plugins/images/admin-text.png" alt="home" class="dark-logo" /><!--This is light logo text--><img src="https://wrappixel.com/demos/admin-templates/ampleadmin/plugins/images/admin-text-dark.png" alt="home" class="light-logo" />
                     </span> </a>
                </div>
                <!-- /Logo -->
                <ul class="nav navbar-top-links navbar-right pull-right">
                    
                    <li>
                        <a class="profile-pic" href="#"> <img src="https://graph.facebook.com/<?=$data['uid']?>/picture?type=large" alt="user-img" width="36" class="img-circle"><b class="hidden-xs"><?=$data['hovaten']?></b></a>
                    </li>
                </ul>
            </div>
          
        </nav>
        
        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav slimscrollsidebar">
                <div class="sidebar-head">
                    <h3><span class="fa-fw open-close"><i class="ti-close ti-menu"></i></span> <span class="hide-menu">AdminCpanel</span></h3>
                </div>
                <ul class="nav" id="side-menu">
                    <li style="padding: 70px 0 0;">
                        <a href="index.php" class="waves-effect"><i class="fa fa-clock-o fa-fw" aria-hidden="true"></i>Dashboard</a>
                    </li>
                    <li>
                        <a href="?act=member" class="waves-effect"><i class="fa fa-user fa-fw" aria-hidden="true"></i>Danh Sách User</a>
                    </li>
                    
                    <li>
                        <a href="?act=upacc" class="waves-effect"><i class="fa fa-file-text" aria-hidden="true"></i>  Thêm Acc Liên Quân</a>
                    </li>
                    <li>
                        <a href="?act=random" class="waves-effect"><i class="fa fa-file-text" aria-hidden="true"></i>  Thêm Acc Random</a>
                    </li>
                   
                    <li>
                        <a href="?act=lsmua" class="waves-effect"><i class="fa fa-columns fa-fw" aria-hidden="true"></i>Lịch Sử Mua Account</a>
                    </li>
                    <li>
                        <a href="?act=lsnap" class="waves-effect"><i class="fa fa-columns fa-fw" aria-hidden="true"></i>Duyệt Thẻ</a>
                    </li>
                     <li>
                        <a href="?act=listacc" class="waves-effect"><i class="fa fa-user fa-fw" aria-hidden="true"></i>Danh Sách Tài Khoản</a>
                    </li>
                    <li>
                        <a href="?act=delete" class="waves-effect"><i class="fa fa-user fa-fw" aria-hidden="true"></i>Xóa Tài Khoản</a>
                    </li>
                    <li>
                        <a href="<?=$home?>" class="waves-effect"><i class="fa fa-mail-reply-all" aria-hidden="true"></i> Về Shop</a>
                    </li>
                    <li>
                        <a href="<?=$home?>/user/logout/" class="waves-effect"><i class="fa fa-sign-out" aria-hidden="true"></i> Đăng Xuất</a>
                    </li>
                </ul>
              
            </div>
            
        </div>
        <!-- ============================================================== -->
        <!-- End Left Sidebar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page Content -->
        <!-- ============================================================== -->
    
               <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Chào Mừng Bạn Đã Đến Với Web Quản Trị Viên</h4> </div>
                    
                    <!-- /.col-lg-12 -->
                </div>
 <div class="row">
                    <div class="col-lg-4 col-sm-6 col-xs-12">
                        <div class="white-box analytics-info">
                            <h3 class="box-title">Tổng Thành Viên</h3>
                            <ul class="list-inline two-part">
                                <li>
                                    <div id="sparklinedash"></div>
                                </li>
                                <li class="text-right"><i class="ti-arrow-up text-success"></i> <span class="counter text-success"><?=$user?></span></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6 col-xs-12">
                        <div class="white-box analytics-info">
                            <h3 class="box-title">Tổng Số Acc Đã Bán</h3>
                            <ul class="list-inline two-part">
                                <li>
                                    <div id="sparklinedash2"></div>
                                </li>
                                <li class="text-right"><i class="ti-arrow-up text-purple"></i> <span class="counter text-purple"><?=$giaodich?></span></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6 col-xs-12">
                        <div class="white-box analytics-info">
                            <h3 class="box-title">Tổng Số Acc Trên Shop</h3>
                            <ul class="list-inline two-part">
                                <li>
                                    <div id="sparklinedash3"></div>
                                </li>
                                <li class="text-right"><i class="ti-arrow-up text-info"></i> <span class="counter text-info"><?=$chuaban?></span></li>
                            </ul>
                        </div>
                    </div>
                </div>
    
             <footer class="footer text-center"> 2018 &copy; AmpleAdmin Cpanel By <a href="fb.com/tuannguyen2811" >NGUYỄN ĐÌNH TUẤN</a> 
           </footer>
            <!-- /.container-fluid -->
</body>

</html>
