<?php
    /*
     *
     *
     *
     *
     */
	# Khai báo sử dụng session
	session_start();
	ob_start();

	# Tiêu đề trang 
	$headtitle = 'Lịch sử giao dịch';
	
	# Check quyền

	# Import Hệ thống
	require('core/database.php');
	if(!$uid){header('location: /index.php'); exit;}// nếu không phải user thì kết thúc và đẩy về trang chủ
	require('core/head.php');
	require('core/history.php');
	require('core/foot.php');

?>
