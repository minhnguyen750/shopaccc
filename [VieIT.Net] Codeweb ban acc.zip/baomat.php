


<html>
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="description" content="Trung tâm hỗ trợ khác hàng của Garena">
      <meta name="author" content="Coderthemes">
      <link rel="shortcut icon" href="https://hotro.garena.vn/static/favicon.ico">
      <title>THAY ĐỔI SỐ ĐIỆN THOẠI VÀ EMAIL GARENA</title>
      <link href="https://hotro.garena.vn/static/css/bootstrap.min.css" rel="stylesheet" type="text/css">
      <link rel="stylesheet" href="https://hotro.garena.vn/static/css/jquery-ui.css">
      <link rel="stylesheet" type="text/css" href="https://hotro.garena.vn/static/css/slick.css">
      <link rel="stylesheet" type="text/css" href="https://hotro.garena.vn/static/css/slick-theme.css">
      <link href="https://hotro.garena.vn/static/css/style.css?v=2017081801" rel="stylesheet" type="text/css">
      <link href="https://hotro.garena.vn/static/css/icon.css" rel="stylesheet" type="text/css">
      <link href="https://hotro.garena.vn/static/css/animate.css" rel="stylesheet" type="text/css">
      <link href="https://hotro.garena.vn/static/css/dropzone.css" rel="stylesheet" type="text/css">
      <link href="https://hotro.garena.vn/static/css/owl.carousel.css" rel="stylesheet">
      <link href="https://hotro.garena.vn/static/css/owl.theme.css" rel="stylesheet">
      <link href="https://hotro.garena.vn/static/css/phieuhotro.css?v=2017081601" rel="stylesheet" type="text/css">
      <script src="https://hotro.garena.vn/static/js/jquery.min.js"></script>
      <script src="https://hotro.garena.vn/static/js/bootstrap.min.js"></script>
      <script src="https://hotro.garena.vn/static/js/jquery-ui.js"></script>
   </head>
   <center>
      <h2><strong>Thay đổi Số Điện Thoại trong tài khoản thì phải làm như thế nào?</strong></h2>
   </center>
   <div class="bootstrap-tabs" data-tab-set-title="trường hợp 1:">
      <ul class="nav nav-tabs" role="tablist">
         <li role="presentation" class="active"><a aria-controls="tr-ng-h-p-1-tab-1" aria-expanded="true" class="tab-link" data-toggle="tab" href="#tr-ng-h-p-1-tab-1" role="tab">Bước 1</a></li>
         <li role="presentation" class=""><a aria-controls="tr-ng-h-p-1-tab-2" aria-expanded="false" class="tab-link" data-toggle="tab" href="#tr-ng-h-p-1-tab-2" role="tab">Bước 2</a></li>
         <li role="presentation" class=""><a aria-controls="tr-ng-h-p-1-tab-3" aria-expanded="false" class="tab-link" data-toggle="tab" href="#tr-ng-h-p-1-tab-3" role="tab">Bước 3</a></li>
         <li role="presentation" class=""><a aria-controls="tr-ng-h-p-1-tab-4" aria-expanded="false" class="tab-link" data-toggle="tab" href="#tr-ng-h-p-1-tab-4" role="tab">Bước&nbsp;4</a></li>
         <li role="presentation" class=""><a aria-controls="tr-ng-h-p-1-tab-5" aria-expanded="false" class="tab-link" data-toggle="tab" href="#tr-ng-h-p-1-tab-5" role="tab">Bước&nbsp;5</a></li>
         <li class="" role="presentation"><a aria-controls="tr-ng-h-p-1-tab-6" aria-expanded="false" class="tab-link" data-toggle="tab" href="#tr-ng-h-p-1-tab-6" role="tab">Bước&nbsp;6</a></li>
      </ul>
      <div class="tab-content">
         <div class="tab-pane active" id="tr-ng-h-p-1-tab-1" role="tabpanel">
            <div class="tab-pane-content"><span style="font-family:Tahoma,Geneva,sans-serif"><span style="font-size:16px">Truy cập vào <a href="http://taikhoan.garena.vn">http://taikhoan.garena.vn</a> và đăng nhập tài khoản Garena cần thay đổi thông tin (không áp dụng với tài khoản Facebook chơi game Garena)</span></span></div>
         </div>
         <div class="tab-pane" id="tr-ng-h-p-1-tab-2" role="tabpanel">
            <div class="tab-pane-content">
               <ul dir="ltr">
                  <li>
                     <p><span style="font-family:Tahoma,Geneva,sans-serif"><span style="font-size:16px">Nhấn vào nút thay đổi như hình bên dưới để bắt đầu thay đổi thông tin số điện thoại xác nhận.</span></span></p>
                  </li>
               </ul>
               <p dir="ltr" style="text-align:center"><span style="font-family:Tahoma,Geneva,sans-serif"><span style="font-size:16px"><img src="https://lh6.googleusercontent.com/_MOXjQ0NVFgLkNfJ_-53-bzPnHle6_lSxVGaFeAmxXgBNcMjqY0SBw7IMXJ09lVFeZo6gF97Rh1d2TlColLcsiLNt6zyrTXGYaJM357ZNiWG2c-1vABWGFWgIi00UFN1cdsGElrF" style="height:235px; width:600px"></span></span></p>
            </div>
         </div>
         <div class="tab-pane" id="tr-ng-h-p-1-tab-3" role="tabpanel">
            <div class="tab-pane-content">
               <ul dir="ltr">
                  <li>
                     <p><span style="font-family:Tahoma,Geneva,sans-serif"><span style="font-size:16px">Ấn Lấy mã và điền mã CODE được gửi tới số điện thoại xác nhận hiện tại vào ô trống. Nhấn XÁC NHẬN</span></span></p>
                  </li>
               </ul>
               <p dir="ltr" style="text-align:center"><span style="font-family:Tahoma,Geneva,sans-serif"><span style="font-size:16px"><img src="https://lh4.googleusercontent.com/Wl4WYoQEzGufmlbdg6nSEopgqfOJAIhH6GgzwdAViyfqWw9FBEmJFyNV7SpE-ivQySoa3K-yazKH5nBM1MN7iEBhlGI5lJuI_hzeVZNT9v58aXj7lqZ5d-39asgI_aXYxG2-WhgJ" style="height:249px; width:600px"></span></span></p>
            </div>
         </div>
         <div class="tab-pane" id="tr-ng-h-p-1-tab-4" role="tabpanel">
            <div class="tab-pane-content">
               <ul dir="ltr">
                  <li>
                     <p><span style="font-family:Tahoma,Geneva,sans-serif"><span style="font-size:16px">Tiếp theo bạn điền số điện thoại mới cần thay đổi vào ô trống, sau đó nhấn Áp dụng</span></span></p>
                  </li>
               </ul>
               <p dir="ltr" style="text-align:center"><span style="font-family:Tahoma,Geneva,sans-serif"><span style="font-size:16px"><img src="https://lh3.googleusercontent.com/VuEv5VvAzytnUUHRmN8Uo4X0XpwVa_IFuwN_KAK6zfMKhNWKOsmcKGvNRFB3h9YBj2HpLKJ4otcXOLpnRi4sROxOIUjZ2At6R5QKM9ouxcQLyMfD7eyNApjZL9VqHC0FuGQGvOeP" style="height:241px; width:600px"></span></span></p>
            </div>
         </div>
         <div class="tab-pane" id="tr-ng-h-p-1-tab-5" role="tabpanel">
            <div class="tab-pane-content">
               <ul dir="ltr">
                  <li><span style="font-family:Tahoma,Geneva,sans-serif"><span style="font-size:16px">Nhấn Lấy mã và nhập mã CODE để xác nhận số điện thoại mới</span></span></li>
               </ul>
               <p dir="ltr" style="text-align:center"><span style="font-family:Tahoma,Geneva,sans-serif"><span style="font-size:16px"><img src="https://lh4.googleusercontent.com/eld8bS1crV0A2tVytbk7iDfcFbH7EfdpFUQKapY-bt5vTsuLWCZIHHbuHGMMXONBz0siLVeao3DZDbOd3wMfH3vbtL86FAcQWw2MlNv1B5GDGHBgsUH26m3ZTlJABCch-2CFqUzp" style="height:246px; width:600px"></span></span></p>
            </div>
         </div>
         <div class="tab-pane" id="tr-ng-h-p-1-tab-6" role="tabpanel">
            <div class="tab-pane-content">
               <ul dir="ltr">
                  <li><span style="font-family:Tahoma,Geneva,sans-serif"><span style="font-size:16px">Nhập mật khẩu hiện tại để hoàn tất đăng ký số điện thoại mới</span></span></li>
               </ul>
               <p dir="ltr" style="text-align:center"><span style="font-family:Tahoma,Geneva,sans-serif"><span style="font-size:16px"><img src="https://lh4.googleusercontent.com/_hBt4WlUt5EPrVN4rhUAd23I8WAn5Arvt5PxpZ-SiGFYkeDiy1N1qukBDSpZT0zgHWlWt9UdSMrKqmWMPxx62LB3dUOEa7pG82k6AL9v3DoxoYj9fH8rOrJEtX0eN9-g7XSL21PN" style="height:247px; width:600px"></span></span></p>
            </div>
         </div>
      </div>
   </div>
   <div class="tab-pane fade active in" id="step3">
   <input type="hidden" value="1" id="display_channel">
   <div class="lienhe">
   <input type="hidden" value="540" id="_faq-id"> 
   <div class="cauhoi col-xs-12">
   <center>
      <h2><strong>Thay đổi Email trong tài khoản thì phải làm như thế nào?</strong></h2>
   </center>      <div>
         <p dir="ltr"><span style="font-family:Tahoma,Geneva,sans-serif"><span style="font-size:16px"><strong>- Tài Khoản:</strong> Email đăng ký trong tài khoản chưa xác thực: vui lòng thay đổi hoặc xác nhận Email thực hiện theo hướng dẫn tại đây để bảo mật tài khoản.</span></span></p>
         <ul dir="ltr">
            <li>
               <p><span style="font-family:Tahoma,Geneva,sans-serif"><span style="font-size:16px"><strong>Bước 1:</strong> Truy cập vào <a href="http://taikhoan.garena.vn">http://taikhoan.garena.vn</a> và đăng nhập tài khoản Garena Plus cần thay đổi Email.</span></span></p>
            </li>
            <li>
               <p><span style="font-family:Tahoma,Geneva,sans-serif"><span style="font-size:16px"><strong>Bước 2:</strong> Nhấn vào nút Xác thực như hình bên dưới để bắt đầu xác nhận Email.</span></span></p>
            </li>
         </ul>
         <p dir="ltr" style="text-align:center"><span style="font-family:Tahoma,Geneva,sans-serif"><span style="font-size:16px"><img src="https://lh3.googleusercontent.com/e96gkkWl9SSSokbCXilJgCM2kN3T1PMG6i2TtpLI2S2IjCu_5zyctX_RrNdLMm_yggFMzodZP1TBjUXoNvf_WXagZZzvBPOiGxZAhbWokEefx5KwNheUhtnNvwmNzDisopATEexk" style="height:233px; width:600px"></span></span></p>
         <ul dir="ltr">
            <li>
               <p><span style="font-family:Tahoma,Geneva,sans-serif"><span style="font-size:16px"><strong>Bước 3:</strong> Nhập địa chỉ Email trước đó bạn đã đăng ký với tài khoản Garena.</span></span></p>
            </li>
         </ul>
         <p dir="ltr" style="text-align:center"><span style="font-family:Tahoma,Geneva,sans-serif"><span style="font-size:16px"><img src="https://lh6.googleusercontent.com/PKLUNLM8IUkcAhu8Wp32eiMjIv_wiUU15p2EDwGr4dfmfRh4HqYgtoEsARr8bnUBPq7YR6mNSydLh0hKxc_1_b64lJKEa3FKBitapRf3DgbeAzI2G6LCjqS6GmUK3hhSAVWD5K_B" style="height:247px; width:600px"></span></span></p>
         <ul dir="ltr">
            <li><span style="font-family:Tahoma,Geneva,sans-serif"><span style="font-size:16px"><strong>Bước 4:</strong>&nbsp;Trong trường hợp muốn thay đổi Email, hãy chọn Thay đổi Email và điền Email mới. Hệ thống sẽ tự động gửi mã về Email mà bạn đã điền.</span></span></li>
         </ul>
         <p dir="ltr" style="text-align:center"><span style="font-family:Tahoma,Geneva,sans-serif"><span style="font-size:16px"><img src="https://lh6.googleusercontent.com/Qz2XziovAZL-s2WqwnM7cODWGdJtmWCeMUYxM3Kyi66XIWyBQxMJID1uihUiJy_XQ_KkNEzAL8W_9jdSBCQq6EqSODtVohbBTenqa80u3mRaNVJDvexrYDhJk66Lb5bHWuaYs_QD" style="height:246px; width:600px"></span></span></p>
         <ul dir="ltr">
            <li><span style="font-family:Tahoma,Geneva,sans-serif"><span style="font-size:16px"><strong>Bước 5:</strong>&nbsp;Kiểm tra email, nhập mã CODE và xác minh để hoàn tất.</span></span></li>
         </ul>
         <p dir="ltr" style="text-align:center"><span style="font-family:Tahoma,Geneva,sans-serif"><span style="font-size:16px"><img src="https://lh6.googleusercontent.com/jQvV0WueT9Eo2yTuFKgFmo25M2ME3OM7hGkUIwoOJyI_yh4KXuZp1-IyrqrrdyvNvXP0lp00haV5pAa6RuGId1AqyOIXqjFzMRRO2L9wToJLUfo16iGQYfk6LxHkjaLPe2gX3MJI" style="height:517px; width:600px"></span></span></p>
      </div>
   </div>
   <br>
   <br>
   <br>
</html>
