    <div class="sa-mainsa">
  <div class="container">
    <div class="sa-logmain sa-themain">
      <div class="row">
        <div class="col-md-4 col-md-offset-4">
          <div class="sa-logbox">
            <ul class="sa-lognav-tabs" role="tablist">
              <li role="presentation" class="active"><a href="#nap-the" role="tab" data-toggle="tab">NẠP THẺ</a></li>
            </ul>
            <div class="sa-logtct tab-content">
              <div role="tabpanel" class="tab-pane active" id="nap-the">
                                <form id="card-charing" novalidate="novalidate">
                  <ul>
                    <li class="sa-logse">
                      <select name="card_type_id" class="form-control">
                        <option value="">Chọn loại thẻ</option>
                        <option value="VTT">Viettel</option>
                        <option value="VMS">Mobiphone</option>
                        <option value="VNP">Vinaphone</option>
                        <option value="VNM">Vietnammobi</option>
                        <option value="ZING">Zing</option>
                      </select>
                    </li>
                    <li class="sa-lichek"><input type="text" name="seri" class="form-control" placeholder="Nhập Serial"></li>
                    <li class="sa-lichek"><input type="text" name="pin" class="form-control" placeholder="Nhập mã thẻ"></li>
                    <li class="sa-librow clearfix">
                      <span><button type="submit" class="sa-lib-dk btn btn-danger">NẠP THẺ</button></span>
                      <span><button type="reset" class="sa-lib-del btn btn-default">NHẬP LẠI</button></span>
                    </li>
                  </ul>
                </form>
                              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
  $(document).ready(function() {
  
      $("#card-charing").validate({
          rules: {
              type: {
                  required: true
              },
              serial: {
                  required: true,
                  minlength: 6
              },
              code: {
                  required: true,
                  minlength: 6
              }
          },
          messages: {
              card_type_id: 'Bạn vui lòng chọn loại thẻ',
              seri: 'Bạn vui lòng nhập serial của thẻ',
              pin: 'Bạn vui lòng nhập mã thẻ'
          },
          submitHandler: function(e) {
  
              if (!$('#card-charing').hasClass('isPosting')) {
                  $('#card-charing').addClass('isPosting');
                  $('#card-charing button[type="submit"]').text('NẠP THẺ...');
  
                  $.post('/Content/ajax/site/vippay.php', $('#card-charing').serialize(), function(res) {
  
                      if (res.err) {
                          web365.utility.toastWarning(res.msg);
                      } else {
                          web365.utility.toastSuccess(res.msg);
                          // document.location.reload();
                      }
  
                  }, "json").complete(function() {
                      $('#card-charing').removeClass('isPosting');
                      $('#card-charing button[type="submit"]').text('NẠP THẺ');
                  });
  
              }
  
              return false;
          }
      });
  
  });
</script>