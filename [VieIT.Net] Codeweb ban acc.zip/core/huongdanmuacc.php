<div class="pusher">
    

  

 <div class="ui inverted vertical masthead center aligned segment he-store">

    <div class="ui center aligned container">
      <h1 class="ui inverted header">
        Hướng dẫn Mua Acc
      </h1>
      <br>
               <span class="bloginfo-publisher-text">Last updated: 02, 04, 2017</span>
          </div>

  </div>
    <div class="hr"></div>

  <div class="ui hidden divider"></div>
  
  


  <div id="post-content" class="ui container">
    <div class="ui basic padded segment">
     <div id="blog-post-content" style="font-size:12pt;">
     <div style="border: 0px; margin: 0px; padding: 0px; text-align: center; vertical-align: baseline;">
<div style="background-color: #181818; border-image-outset: initial; border-image-repeat: initial; border-image-slice: initial; border-image-source: initial; border-image-width: initial; border: 0px; margin: 0px; padding: 0px; text-align: center; vertical-align: baseline;">
<div style="background-color: #181818; border-image-outset: initial; border-image-repeat: initial; border-image-slice: initial; border-image-source: initial; border-image-width: initial; border: 0px; margin: 0px; padding: 0px; text-align: center; vertical-align: baseline;">
<div style="border-image-outset: initial; border-image-repeat: initial; border-image-slice: initial; border-image-source: initial; border-image-width: initial; border: 0px; margin: 0px; padding: 0px; vertical-align: baseline;">
<div style="background-color: #181818; font-family: inherit; font-style: inherit; font-variant: inherit; line-height: inherit;"><div style="text-align: left;">











<div class="separator" style="clear: both; text-align: center;">
<b><br></b></div>
<u><b><span style="color: orange;">MUA TRỰC TIẾP TẠI NHÀ,CHUYỂN KHOẢN,ATM :</span></b></u><br>
<b><u><br></u>
</b><br>
<div class="MsoNormal">
<span lang="EN-US"><b>CÁCH GIAO DỊCH
CHUYỂN KHOẢN :<o:p></o:p></b></span></div><br>
<b><span style="color: red;">Các bạn liên hệ SDT 0167.475.4257 or FB AD để lấy STK ngân hàng</span></b> <br><br>
<span lang="EN-US"><b>Nội dung
chuyển khoản các bạn ghi số điện thoại của các bạn và mã số acc mua (VD:
01674754257, mua acc #100)<o:p></o:p></b></span></div>
<div class="MsoNormal">
<span lang="EN-US"><b>Sau khi
chuyển khoản các bạn liên hệ mình để xác nhận và nhận tài khoản qua :<o:p></o:p></b></span></div>
<div class="MsoListParagraphCxSpFirst" style="mso-list: l0 level1 lfo1; text-indent: -18.0pt;">
<!--[if !supportLists]--><b><span lang="EN-US">-<span style="font-size: 7pt; font-stretch: normal; font-variant-numeric: normal; line-height: normal;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span lang="EN-US">Facebook.com/WelComeToAccountSangdz.Vn
<o:p></o:p></span></b></div>
<div class="MsoListParagraphCxSpLast" style="mso-list: l0 level1 lfo1; text-indent: -18.0pt;">
<!--[if !supportLists]--><b><span lang="EN-US">-<span style="font-size: 7pt; font-stretch: normal; font-variant-numeric: normal; line-height: normal;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span lang="EN-US">Số
điện thoại  0167.475.4257<o:p></o:p></span></b></div>
<div class="MsoNormal">
<span lang="EN-US"><b>Lưu ý : Khi
tiền vào tài khoản mình mới chuyển acc cho các bạn nhé [Yên tâm rằng nếu chuyển
đúng tiền vào đúng tài khoản bên trên thì chắc chắn các bạn sẽ không mất mát
gi]<o:p></o:p></b></span></div>
<div class="MsoNormal">
<b><br></b></div>
<div class="MsoNormal">
<span lang="EN-US"><b><u><span style="color: orange;">CÁCH GIAO DỊCH
TRỰC TIẾP :</span></u><o:p></o:p></b></span></div>
<div class="MsoNormal">
<span lang="EN-US"><b>Trước khi
qua giao dịch trực tiếp các bạn gọi vào số khu vực bên dưới để xem tài khoản bạn
muốn mua còn không và báo thời gian các bạn qua (nên gọi trước 30p)<o:p></o:p></b></span></div>
<div class="MsoNormal">
<span lang="EN-US"><b><span style="color: red;"><u>Khu vực
Bến Tre :</u> </span><span style="color: orange;">(Địa chỉ nhà Riêng)</span><u><o:p></o:p></u></b></span></div>
<div class="MsoListParagraphCxSpFirst" style="mso-list: l0 level1 lfo1; text-indent: -18.0pt;">
<!--[if !supportLists]--><b><span lang="EN-US">-<span style="font-size: 7pt; font-stretch: normal; font-variant-numeric: normal; line-height: normal;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span lang="EN-US">Điện
Thoại : 0167.475.4257 <o:p></o:p></span></b></div>
<div class="MsoListParagraphCxSpLast" style="mso-list: l0 level1 lfo1; text-indent: -18.0pt;">
<!--[if !supportLists]--><b><span lang="EN-US">-<span style="font-size: 7pt; font-stretch: normal; font-variant-numeric: normal; line-height: normal;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span lang="EN-US">Địa
Chỉ : Thị Trấn Huyện Giồng Trôm Bến Tre <o:p></o:p></span></b></div>
<div class="MsoNormal">
<b><span lang="EN-US" style="color: red;"><u style="color: red;">Khu vực
Bến Tre :</u><span style="color: red;"> &nbsp;</span><span style="color: orange;"></span></span></b></div>
<div class="MsoListParagraphCxSpFirst" style="mso-list: l0 level1 lfo1; text-indent: -18.0pt;">
<!--[if !supportLists]--><b><span lang="EN-US">-<span style="font-size: 7pt; font-stretch: normal; font-variant-numeric: normal; line-height: normal;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span lang="EN-US">Điện
Thoại : update... <o:p></o:p></span></b></div>
<div class="MsoListParagraphCxSpLast" style="mso-list: l0 level1 lfo1; text-indent: -18.0pt;">
<!--[if !supportLists]--><b><span lang="EN-US">-<span style="font-size: 7pt; font-stretch: normal; font-variant-numeric: normal; line-height: normal;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span lang="EN-US">Địa
Chỉ : update... <o:p></o:p></span></b></div>
<div class="MsoNormal">
<span lang="EN-US"><b>Hình thức :
Đây đều là nhà riêng của bọn mình nên khi các bạn đến sẽ giao dịch
theo trình tự :<o:p></o:p></b></span></div>
<div class="MsoNormal">
<span lang="EN-US"><b>Check acc
(Kiểm tra tài khoản) —&nbsp; Chuyển,kích hoạt
thông tin – Nhận,lưu tài khoản – Giao tiền <o:p></o:p></b></span></div>
<b><br></b>
<br>
<div class="MsoNormal">
<span lang="EN-US"><b>Shop hoàn
thành cho tới khi bạn thực sự yên tâm và hài lòng mới nhận tiền nhé!<o:p></o:p></b></span></div>
<div class="MsoNormal">
<span lang="EN-US"><b><br></b></span></div>
<div class="MsoNormal">
<span lang="EN-US" style="color: orange;"><u><b>GIAO DỊCH THÔNG QUA SĐT,FACEBOOK PAGE :</b></u></span></div>
<div class="MsoNormal">
<b><br></b></div>
<div class="MsoNormal">
<b>Rất đơn giản các bạn chỉ việc chọn acc, sau đó liên hệ qua :</b></div>
<div class="MsoNormal" style="text-align: center;">
<b>Facebook.com/WelComeToAccountSangdz.Vn</b></div>
<div class="MsoNormal" style="text-align: center;">
<b><span style="color: red;">SĐT: 0167.475.4257&nbsp;</span></b></div>
<div class="MsoNormal" style="text-align: center;">
<b>(Tất cả mọi yêu cầu hoặc thắc mắc sẽ được giải đáp ngay tức khắc) Online<span style="color: red;"> 24/7</span>&nbsp;</b></div>
<div class="MsoNormal">
<b><br></b></div>
</div>
<span style="color: red; font-size: x-large;"><b>Hướng dẫn mua acc&nbsp;</b></span><br>
<b><br></b>
<br>
<div style="text-align: left;">
<b>Sau khi xem tài khoản tại trang chủ WWW.SHOPACCLMHT369.TK các bạn có thể mua qua những hình thức sau :</b><br>
<u><b><br></b></u></div>
<div style="text-align: left;">
<u><span style="color: orange;"><b>MUA TỰ ĐỘNG BẰNG CARD (Thẻ Cào) :</b></span></u></div>
<b><br></b>
<br>
<div style="text-align: left;">
<b>1/ Các bạn Nạp Tiền vào Tài Khoản :</b></div>
<div style="text-align: left;">
<b>- Ấn vào Nạp Tiền ở trên cùng thanh Công Cụ</b></div>
<div class="separator" style="clear: both; text-align: center;">
<a href="http://shopacclmht369.tk/" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><b><img border="0" src="https://2.bp.blogspot.com/-htg9zoY9vFE/WJ2IlnaaDbI/AAAAAAAAbQM/1h9q-L-tfMIvIhL58Dz3N-UyLsp1xKzzgCLcB/s1600/bandicam%2B2017-02-10%2B16-31-35-472.jpg"></b></a></div>
<div style="text-align: left;">
<span style="font-family: inherit; font-style: inherit;"><b><br></b></span></div>
<div style="text-align: left;">
<span style="font-family: inherit; font-style: inherit;"><b>2/ Tiếp theo Chọn loại thẻ(1) rồi Nhập Seri(2), Mã Thẻ(3) vào ô tương ứng và Click Nạp Thẻ.</b></span></div>
<div class="separator" style="clear: both; text-align: center;">
</div>
<a href="http://shopacclmht369.tk/" imageanchor="1" style="font-family: inherit; font-style: inherit; font-variant-caps: inherit; font-variant-ligatures: inherit; margin-left: 1em; margin-right: 1em;"><b><img border="0" src="https://1.bp.blogspot.com/-Hk80NNvk-KA/WJ2JeIYueWI/AAAAAAAAbQc/UJvSKA0rXe4-XzNiY7rgmTOybbM21md_gCLcB/s1600/bandicam%2B2017-02-10%2B16-30-12-236.jpg"></b></a><br>
<b><br></b>
<br>
<div style="text-align: left;">
<b>3/ Sau khi có đủ tiền các bạn ấn Mua Ngay và thanh toán sẽ hoàn tất và chuyển tới phần hiển thị tài khoản bạn mua . Các bạn có thể kiểm tra tài khoản và lịch sử Nạp Thẻ ở phần Lịch sử giao dịch.</b></div>
<div class="separator" style="clear: both; text-align: center;">
</div>
<div class="separator" style="clear: both; text-align: center;">
<a imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><b><img border="0" src="https://1.bp.blogspot.com/-4ZWVT0y_C4I/WJ2LqfUhIlI/AAAAAAAAbQ8/SHJfkZpaJlQ6VcD2m3PJzrpIAwd_EbwUQCLcB/s1600/bandicam%2B2017-02-10%2B16-25-09-497.jpg"></b></a></div><b><br></b><br><div class="separator" style="clear: both; text-align: center;">
<a imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><b><img border="0" src="https://2.bp.blogspot.com/-qC1fmPkEy48/WJ2LqBU-yUI/AAAAAAAAbQ4/n_nBJqyoGkouYBDtW9bGOY6H81mo9Mv2gCLcB/s1600/bandicam%2B2017-02-10%2B16-25-45-529.jpg"></b></a></div><div class="separator" style="clear: both; text-align: center;">
<b><br></b></div><div class="separator" style="clear: both; text-align: center;">
<a href="http://shopacclmht369.tk/lich-su-mua/" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><b><img border="0" src="https://3.bp.blogspot.com/-zu4x0U3LblE/WJ29k8TlQuI/AAAAAAAAbRQ/EMMADovAEIg9QqgTV0W9TnAwcGadMWUxACLcB/s1600/bandicam%2B2017-02-10%2B20-16-37-443.jpg"></b></a></div><div class="separator" style="clear: both; text-align: center;">
<b><br></b></div><div class="separator" style="clear: both; text-align: center;">
<b><br></b></div><div class="separator" style="clear: both; text-align: center;">
<b><br></b></div><div class="separator" style="clear: both; text-align: center;">
<b>Cuối cùng các bạn ấn vào Hướng Dẫn Kích Hoạt và làm theo hướng dẫn để bảo mật tài khoản .</b></div><div class="separator" style="clear: both; text-align: center;">
<b>Chúc các bạn chơi game vui vẻ !</b></div>
<div style="text-align: left;">
<div style="text-align: center;">
<b><br></b></div>
</div>
</div>
</div>
</div>
</div>
</div>
<br>

      </div>
    </div>

  <br>
  <div class="ui divider"></div>
  </div>

  



  </div>
