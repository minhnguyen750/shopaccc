<?php
require('fbconfig.php');
     /*
Đăng ký kênh Học Viện Game nha
Để nhận hỗ trợ code nha
Link: https://youtube.com/c/hocviengame

     */

if(!$_SESSION['facebook_access_token']){
/*try {
 	$response = $fb->get('/me?fields=id,name,email');
 	$user = $response->getGraphUser();

} catch(Facebook\Exceptions\FacebookResponseException $e) {
  //echo 'Graph returned an error: ' . $e->getMessage();
} catch(Facebook\Exceptions\FacebookSDKException $e) {
  //echo 'Facebook SDK returned an error: ' . $e->getMessage();
}*/
$helper = $fb->getRedirectLoginHelper();
$permissions = ['user_about_me'];  // set the permissions. https://shopacclm247.vn/assets/images/logo.png
$loginUrl = $helper->getLoginUrl(''.$home.'/login.php', $permissions);
}
?>
<!DOCTYPE html>
<html>
   <!--   -->
               <!--   -->
   <!--   -->
<head> 
    <title><?php echo isset($headtitle) ? ''.$headtitle.'' : 'Shop Liên Quân - Shop Mua Bán Acc Liên Quân Mobile Giá Rẻ Uy Tín Hàng Đầu VN'; ?></title>
    <meta name="description" content="Mua acc liên quân giá rẻ,Shop Liên Quân uy tín số 1 VN , shop kinass ">
    <meta name="keywords" content="Mua acc liên quân giá rẻ, Shop Liên Quân uy tín số 1 VN , shop kinass ">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta property="og:type" content="website">
    <meta property="og:title" content="Mua acc liên quân giá rẻ , Shop Liên Quân uy tín số 1 VN">
    <meta property="og:description" content="Mua acc liên quân giá rẻ , Shop Liên Quân uy tín số 1 VN">
    <link rel="icon" href="https://sv1.uphinhnhanh.com/images/2018/07/01/lien-quan-mobile-violet-va-5-vi-tuong-danh-dau-thang-do-giai-doa-5f60e3.jpg">
    <link rel="stylesheet" type="text/css" href="<?=$home?>/assets/css/custom.css?tuannguyen2811=<?=rand(1,10000)?>">
           <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <!-- Favicons -->
    <link rel="icon" href="/assets/images/favicon.ico">
    <!-- Css -->
    <link href="https://shopdat09.com/assets/css/bootstrap.css" rel="stylesheet" />
    <link href="https://shopdat09.com/assets/css/swiper.css" rel="stylesheet" />
    <link href="https://shopdat09.com/assets/css/reset.css" rel="stylesheet" />
    <link href="https://shopdat09.com/assets/css/style.css" rel="stylesheet" />
    <link href="https://shopdat09.com/assets/css/site.css" rel="stylesheet" />
    <link href="https://shopdat09.com/assets/css/sweetalert.css" rel="stylesheet">
    
    <link href="https://shopdat09.com/assets/css/AppCss/jquery.scrolltop.css" rel="stylesheet" type="text/css">
    <script src="https://shopdat09.com/assets/js/AppScripts/jquery-1.11.2.js"></script>
    <script src="https://shopdat09.com/assets/js/bootstrap.min.js"></script>
    <script src="https://shopdat09.com/assets/js/AppScripts/jquery.validate.min.js"></script>
    <script src="https://shopdat09.com/assets/js/sweetalert.min.js"></script>
    <script src="https://shopdat09.com/assets/js/AppScripts/jquery-ui.js"></script>
    <script src="https://shopdat09.com/assets/js/AppScripts/jquery.scrolltop.js"></script>
    <script src="https://shopdat09.com/assets/js/swiper.js"></script>
    <script src="https://shopdat09.com/assets/js/functions.js"></script>
 
<link rel="alternate" href="/" hreflang="x-default" />
<meta name="google-site-verification" content="v7rF6PlCZKz0ctnjQ4axy28cIuxckZNTdRkOFDF0YFE" />
      <style>
        body {
    font-family: "Open Sans", "Helvetica Neue", Helvetica, Arial, sans-serif;
    font-size: 14px;
    color: #e5e3e3;
    background: url(https://taikhoanlq.com/tep-tin/976003bg.jpg)!important;
background-size: cover!important;
background-repeat: no-repeat!important;
background-attachment: fixed!important;
background-position: center!important;

}
    </style>




    <style type="text/css">
        
        a.float-btn {
            background: #000;
            width: 180px;
            height: 41px;
            display: block;
            border: 2px solid #000;
            font-size: 17px;
            line-height: 34px;
            text-align: center;
            color: #fff;
            margin: 0 0 1px 0
        }
        
        .float-menu {
            width: 179px;
            position: fixed;
            right: 0;
            top: 40%;
            z-index: 999;
            transition: all ease 0.3s;
            -moz-transition: all ease 0.3s;
            -ms-transition: all ease 0.3s;
            -o-transition: all ease 0.3s;
            -webkit-transition: all ease 0.3s;
        }
    </style>
    <div class="float-menu visible-lg-block" style="margin-right: 0px;">
	<a href="/" class="float-btn" style="background: #FDB603; color: #000;"><img src="https://webnick24h.com/assets/images/LQ.png"> Nick LQMB</a>
	<a href="https://www.facebook.com/adminshopacc" target="_blank" class="float-btn" style="background: #3b5998;"><i class="fa fa-facebook" aria-hidden="true"></i> Liên hệ FB Admin</a>
</div>    
   <div class="sa-header">
      <div class="container">
        <span class="sa-imn"><i class="glyphicon glyphicon-menu-hamburger"></i></span>
        <a class="sa-logo" href="/" title=""><img src="https://i.imgur.com/UyAN7kT.png" alt="" >
        </a>
        <ul class="sa-menu clearfix">
          <li class="active" ><a href="/" title="Trang chủ"><b>Trang chủ</b></a></li>
          <li >
                <div class="btn-group">
                    <a class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <b>Hướng dẫn <span class="caret"></span></b>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a href="/huong-dan-mua-acc.html" title="Hướng dẫn mua acc" style="color:#444;font-size: 15px;">Hướng dẫn mua acc</a></li>
                        <li><a href="/bao-mat.html" title="Hướng dẫn bảo mật TK" style="color:#444;font-size: 15px;">Hướng dẫn bảo mật TK</a></li>
                    </ul>
                </div>
            </li>               
          <li><a href="/nap-the.html" title="Nạp tiền"><b>Nạp Tiền </b></a></li>
        </ul>
        <!-- <button class="btn-search">Tìm kiếm</button> -->
            </ul>
			<?php if (!@$uid):?>
                        <ul class="sa-login clearfix">
                            <li><a href="<?=$loginUrl?>">Đăng Nhập</a></li>
            </ul>
			<?php else:?>
			<div class="sa-user">
                <div class="dropdown">
               <button class="sa-usmoney  dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"> Chào <?=$data['hovaten']?> | <span>Bạn có:</span> <strong><?=number_format($data['cash'], 0, '.', '.')?> VNĐ</strong></button>
                    <ul class="sa-usmenu dropdown-menu dropdown-menu-right">
                        <?php if ($data['admin'] > 0): ?><li><a href="/admincp" title="ACP">Admin CPanel</a></li><?php endif; ?>
			            <li><a href="<?=$home?>/lich-su-mua/" title="Tài khoản đã mua">Tài khoản đã mua</a></li>
                        <li><a href="<?=$home?>/lich-su-nap/" title="Lịch sử nạp tiền">Lịch sử nạp tiền</a></li>
                        <li><a href="<?=$home?>/user/logout/" title="Đăng xuất">Đăng xuất</a></li>
                    </ul>
                </div>
            </div>
			<?php endif;?>
		  </li>
        </ul>
              </div>
    </div>

                        </ul>
                    </nav>
                </div>
            </header><br><br>




