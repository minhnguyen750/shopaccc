<div class="sa-banner">
      <div class="container">
        <div class="sa-bntab clearfix">
          <div class="sa-bncol2">
            <div class="swiper-container sabner">
              <div class="swiper-wrapper">
                <div class="swiper-slide">
                      <!--<div class="embed-container"><iframe src="https://www.youtube.com/embed/o_O8k_yhbqg" frameborder="0" allowfullscreen=""></iframe></div>-->
                    <iframe width="860" height="375" src="https://www.youtube.com/embed/CxXN5DmI9s4?" frameborder="0" allowfullscreen></iframe>
                </div>
        </div>
                    </div>
                </div>
         </a><div class="sa-bncol1">
                    <div class="sa-bntbox">
                        <ul class="sa-bnnav-tabs" role="tablist">
                            <li role="presentation" class="active"><a href="#topnap" role="tab" data-toggle="tab">Top nạp thẻ</a>
                            </li>
                            <li role="presentation" class=""><a href="#thuong" role="tab" data-toggle="tab">Phần thưởng</a>
                            </li>
                        </ul>
              <div class="sa-bntcbox tab-content">
                <div role="tabpanel" class="tab-pane active" id="topnap">
                  <div class="sa-bntabbox mcustomscrollbar">
                    <ul class="sa-topthe">
                       <?php
                        $i=1;
$cash = mysql_query("SELECT * FROM `top` WHERE `ucash` >= '10000' order by ucash desc LIMIT 5");
if (mysql_num_rows($cash) == 0):
?>
<li><p>Chưa có ai đứng top</p></li>
<?php else: while ($row = mysql_fetch_array($cash, MYSQL_ASSOC)):?>
<li>
<i><?=$i?></i>
<span><a href="https://facebook.com/<?=$row['uid']?>"><?=$row['uname']?></a></span>
<label><?=number_format($row['ucash'], 0, '.', '.')?><sup>đ</sup>
</label>
</li>
<?php $i++; endwhile; endif; ?> 
                      
                                          </ul>
                  </div>
                </div>
                <div role="tabpanel" class="tab-pane " id="thuong">
                  <div class="sa-bntabbox mcustomscrollbar">
                    <ul class="sa-pthuong">
                      <li>
                        <label><strong>TOP 1:</strong> Thẻ Cào 100.000 VNĐ</label>
                      </li>
                      <li>
                        <label><strong>TOP 2:</strong> 80.000 VNĐ trên web shop</label>
                      </li>
                      <li>
                        <label><strong>TOP 3:</strong> 70.000 VNĐ trên web shop</label>
                      </li>
                      <li>
                        <label><strong>TOP 4:</strong> 60.000 VNĐ trên web shop</label>
                      </li>
                      <li>
                        <label><strong>TOP 5:</strong> 50.000 VNĐ trên web shop</label>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <br>
<style>
    .tm-statistic .txt-stt h2 {
        font: bold 40px/40px Arial, sans-serif;
        color: #f3bb6b;
        text-shadow: 0 0 5px rgba(0, 0, 0, 0.75);
    }
    
    .about-home {
        width: 100%;
        color: black;
        float: left;
        clear: both;
        display: block;
        font-size: 14px;
        line-height: 22px;
        padding: 2%;
        margin-bottom: 5px;
        border: 1px solid #ddd;
        border-radius: 4px;
        background: #f5f5f5;
    }
    
    #prlg-Wrapper {
        overflow: hidden;
        /* width: 964px; */
        
        background-color: #333;
        height: 266px;
        margin-top: 25px;
        border: 4px solid white;
    }
    /* line 32, ../sass/screen.scss */
    
    #prlg-Container {
        width: 2000px;
    }
    /* line 35, ../sass/screen.scss */
    
    #prlg-Container .prlg-skewCon {
        position: relative;
        left: -77px;
        top: -41px;
        overflow: hidden;
        height: 407px;
        -webkit-transform: skew(-24deg, 0);
        -moz-transform: skew(-24deg, 0);
        -ms-transform: skew(-24deg, 0);
        -o-transform: skew(-24deg, 0);
        transform: skew(-24deg, 0);
        float: left;
        border-right: 10px solid white;
    }
    /* line 46, ../sass/screen.scss */
    
    #prlg-Container .prlg-unSkewCon {
        width: 100%;
        -webkit-transform: skew(24deg, 0);
        -moz-transform: skew(24deg, 0);
        -ms-transform: skew(24deg, 0);
        -o-transform: skew(24deg, 0);
        transform: skew(24deg, 0);
        position: relative;
        left: -42px;
        top: 11px;
        display: block;
    }
    /* line 55, ../sass/screen.scss */
    
    #prlg-Container .prlg-image img {
        /* width: 400px; */
        
        -webkit-animation: blur 1s ease-in-out;
    }
    /* line 59, ../sass/screen.scss */
    
    #prlg-Container .prlg-image:hover b.vl {
        border: 2px solid white;
        display: block;
    }
    /* line 63, ../sass/screen.scss */
    
    #prlg-Container .prlg-title {
        background: rgb(253, 182, 3);
        /* height: 32px; */
        
        line-height: 34px;
        position: absolute;
        padding-left: 24px;
        /* text-transform: uppercase; */
        
        text-align: left;
        top: 30px;
        left: 104px;
        width: 100%;
    }
    /* line 74, ../sass/screen.scss */
    
    #prlg-Container .prlg-title a {
        color: #fff;
    }
    /* line 79, ../sass/screen.scss */
    
    #prlg-Container .bottom .prlg-title {
        top: 29px;
        left: 42px;
    }
    /* line 84, ../sass/screen.scss */
    
    #prlg-Container .prlg-skewCon.bottom:first-child .prlg-title {}
    
    b.vl {
        display: none;
        background-color: rgba(239, 0, 0, 0.075) !important;
        position: absolute;
        top: 22%;
        left: 20%;
        color: #fdb603;
        padding: 7px;
        font-size: 35px;
    }
    
    @media only screen and (min-device-width: 320px) and (max-device-width: 480px) {
        b.vl {
            display: block;
            background-color: rgba(239, 0, 0, 0.075) !important;
            position: absolute;
            top: 23%;
            left: 12%;
            color: #ffffff;
            padding: 7px;
            font-size: 29px;
        }
    }
}
</style>
<div class="sa-mainsa">
    <div class="container">
        <div id="prlg-Wrapper">
            <div id="prlg-Container">
                <div class="prlg-skewCon bottom" style="width:10%;    background: rgb(253, 182, 3);">
                    <div class="prlg-unSkewCon">
                        <a class="prlg-image" href="#1"> <img src=""> </a>
                        <div class="prlg-title">
                            Liên Quân
                            <br> Đã bán : <span><?=$daban_lq?></span>                            <br> Chưa bán : <?=$lienquan?></div>
                    </div>
                </div>
                <div class="prlg-skewCon bottom" style="width:70%">
                    <div class="prlg-unSkewCon">
                        <a class="prlg-image" href="/lien-quan.html"> <b class="vl">Mua ngay</b><img src="https://i.imgur.com/wLAGsRk.png"> </a>



                    </div>
                </div>


            </div>
        </div>

        <div id="prlg-Wrapper">
            <div id="prlg-Container">
                <div class="prlg-skewCon bottom" style="width:10%;    background: rgb(253, 182, 3);">
                    <div class="prlg-unSkewCon">
                        <a class="prlg-image" href="#1"> <img src=""> </a>
                        <div class="prlg-title">
                            RANDOM
                            <br> Đã bán : <span><?=$daban_rd?></span>                             <br> Chưa bán : <span><?=$random?></div>
                    </div>
                </div>
                <div class="prlg-skewCon bottom" style="width:60%">
                    <div class="prlg-unSkewCon">
                        <a class="prlg-image" href="/random.html"> <b class="vl">Mua ngay</b><img src="https://i.imgur.com/UWgokAK.png"> </a>



                    </div>
                </div>


            </div>
        </div>
