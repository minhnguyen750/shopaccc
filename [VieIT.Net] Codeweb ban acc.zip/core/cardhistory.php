   <div class="sa-mainsa">
    <div class="container">
        <div class="sa-lprod">
            <div class="sa-lpmain">
                <div class="sa-lsnmain clearfix">
                    <div class="sa-ls-table table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <td>STT</td>
                                    <td>NGÀY NẠP</td>
                                    <td>SỐ SERIAL</td>
                                    <td>MÃ THẺ</td>
                                    <td>MỆNH GIÁ</td>
                                    <td>Trạng thái</td>
                                </tr>
                            </thead>
                            <tbody>
                            
<?php 
                          
$i=1;$giaodichx = mysql_query("SELECT * FROM `lichsunap` WHERE `uid` = '".$uid."' order by id desc");
if (mysql_num_rows($giaodichx) == 0):
?>
<tr><td colspan="6" class="text-center"><p>Bạn Chưa Có Cuộc Giao Dịch Nào</p></td></tr>
<?php else: while ($row = mysql_fetch_array($giaodichx, MYSQL_ASSOC)):?>
<tr>
<td class="text-primary"><?=$i?></td><td class="text-primary"><?=$row['date']?></td>
<td class="text-primary"><?=$row['serial']?></td><td class="text-primary"><?=$row['mathe']?></td><td class="text-primary"><?=$row['menhgia']?></td>
<td class="text-primary"><?=$row['note']?></td>

</tr>
<?php $i++; endwhile; endif; ?>

                           </tbody>
                        </table>
                    </div>
                </div>
                            </div>
        </div>
    </div>
</div>