
<?php 
     /*


     */
    header('Content-Type: text/html; charset=utf-8');
    session_start();
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $ketnoi['host'] = 'localhost'; //Tên server, nếu dùng hosting free thì cần thay đổi
    $ketnoi['dbname'] = 'dfdfdf'; //Đây là tên của Database
    $ketnoi['username'] = 'shimsvdfdfxd_a'; //Tên sử dụng Database
    $ketnoi['password'] = 'dfdf';//Mật khẩu của tên sử dụng Database
    @mysql_connect("{$ketnoi['host']}","{$ketnoi['username']}","{$ketnoi['password']}") or die("Không thể kết nối database");
    @mysql_select_db( "{$ketnoi['dbname']}") or die("Không thể chọn database");
    mysql_set_charset("utf8");
    // lấy dữ liệu user trong csdl thông qua sesion
    if (isset($_SESSION['username']) && $_SESSION['username']){
    $uid = $_SESSION['username'];
    $data = mysql_fetch_array(mysql_query("SELECT * FROM `nguoidung` WHERE `uid` = '".$uid."' LIMIT 1"));// get dữ liệu từ trong data theo user id
    }
    $home = 'https://'.$_SERVER['HTTP_HOST'].'';// lấy tên miền
    $lienquan = mysql_result(mysql_query("SELECT COUNT(*) FROM `baidang` WHERE `loainick` = 'LQ' AND `trangthai` !='off' LIMIT 1"), 0);
    $random = mysql_result(mysql_query("SELECT COUNT(*) FROM `baidang` WHERE `loainick` = 'RD' AND `trangthai` !='off' LIMIT 1"), 0);
    $chuaban = mysql_result(mysql_query("SELECT COUNT(*) FROM `baidang` WHERE `trangthai` !='off' LIMIT 1"), 0);
    $daban_lq = mysql_result(mysql_query("SELECT COUNT(*) FROM `baidang` WHERE `loainick` = 'LQ' AND `trangthai` !='on' LIMIT 1"), 0);
    $daban_rd = mysql_result(mysql_query("SELECT COUNT(*) FROM `baidang` WHERE `loainick` = 'RD' AND `trangthai` !='on' LIMIT 1"), 0);
    $user = mysql_result(mysql_query("SELECT COUNT(*) FROM `nguoidung` LIMIT 1"), 0);
    $giaodich = mysql_result(mysql_query("SELECT COUNT(*) FROM `lichsumua` LIMIT 1"), 0);
    $now = getdate();
    // func đếmn ngược thời gian (dạng giống facebook) 
    function time_stamp($time)
    {

   $periods = array("giây", "phút", "giờ", "ngày", "tuần", "tháng", "năm", "thập kỉ");
   $lengths = array("60","60","24","7","4.35","12","10");

   $now = time();

       $difference     = $now - $time;
       $tense         = "trước";

   for($j = 0; $difference >= $lengths[$j] && $j < count($lengths)-1; $j++) {
       $difference /= $lengths[$j];
   }

   $difference = round($difference);

 

   return "Cách đây $difference $periods[$j]";
    }

    // Func thống kê online
    function getAmungStats($amung) {
    if(!isset($amung)) return false;
 
    $url = 'http://whos.amung.us/sitecount/' . $amung . '/';
    $result = '';
    if (function_exists('curl_init')) {
      $http_headers                           = array();
      $http_headers[]                         = 'Expect:';
      $http_headers[]                         = 'Content-Type: text/plain';
      $http_headers[]                         = 'Host: whos.amung.us';
      $opts                                   = array();
      $opts[CURLOPT_URL]                      = $url;
      $opts[CURLOPT_HTTPHEADER]               = $http_headers;
      $opts[CURLOPT_CONNECTTIMEOUT]           = 5;
      $opts[CURLOPT_TIMEOUT]                  = 10;
      $opts[CURLOPT_USERAGENT]                = 'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.57 Safari/537.17';
      $opts[CURLOPT_HEADER]                   = FALSE;
      $opts[CURLOPT_RETURNTRANSFER]           = TRUE;
      
      # Initialize PHP/CURL handle
      $ch = curl_init();
      curl_setopt_array($ch, $opts);
      # Create return array
      $result = curl_exec($ch);
      curl_close($ch);
    } elseif (ini_get('allow_url_fopen')) {
      $result = file_get_contents($url);
    }
 
    return intval($result);
}

function get_string_khung($khung) {
    switch ($khung) {
        case 0:
            $str = "Không Khung";
            break;
        case 1:
            $str = "Khung Bạc";
            break;
        case 2:
            $str = "Khung Vàng";
            break;
        case 3:
            $str = "Khung Bạch Kim";
            break;
        case 4:
            $str = "Khung Kim Cương";
            break;
        case 5:
            $str = "Khung Cao Thủ";
            break;
        case 6:
            $str = "Khung Thách Đấu";
            break;
        default:
            $str = "Chưa Xác Định";
            break;
    }
    return $str;
}

function get_bieutuong_khung($khung) {
    switch ($khung) {
        case 0:
            $str = "chuarank.png";
            break;
        case 1:
            $str = "bac.png";
            break;
        case 2:
            $str = "vang.png";
            break;
        case 3:
            $str = "bachkim.png";
            break;
        case 4:
            $str = "kimcuong.png";
            break;
        case 5:
            $str = "master.png";
            break;
        case 6:
            $str = "Khung Thách Đấu";
            break;
        default:
            $str = "chuarank.png";
            break;
    }
    return $str;
}

function get_string_rank($rank)
{
    switch ($rank) {
        case 0:
            $str = "Chưa Rank";
            break;
        case 1:
            $str = "Chưa xác định";
            break;
        case 2:
            $str = "Đồng V";
            break;
        case 3:
            $str = "Đồng IV";
            break;
        case 4:
            $str = "Đồng III";
            break;
        case 5:
            $str = "Đồng II";
            break;
        case 6:
            $str = "Đồng I";
            break;
        case 7:
            $str = "Bạc V";
            break;
        case 8:
            $str = "Bạc IV";
            break;
        case 9:
            $str = "Bạc III";
            break;
        case 10:
            $str = "Bạc II";
            break;
        case 11:
            $str = "Bạc I";
            break;
        case 12:
            $str = "Vàng V";
            break;
        case 13:
            $str = "Vàng IV";
            break;
        case 14:
            $str = "Vàng III";
            break;
        case 15:
            $str = "Vàng II";
            break;
        case 16:
            $str = "Vàng I";
            break;
        case 17:
            $str = "Bạch Kim V";
            break;
        case 18:
            $str = "Bạch Kim IV";
            break;
        case 19:
            $str = "Bạch Kim III";
            break;
        case 20:
            $str = "Bạch Kim II";
            break;
        case 21:
            $str = "Bạch Kim I";
            break;
        case 22:
            $str = "Kim Cương V";
            break;
        case 23:
            $str = "Kim Cương IV";
            break;
        case 24:
            $str = "Kim Cương III";
            break;
        case 25:
            $str = "Kim Cương II";
            break;
        case 26:
            $str = "Kim Cương I";
            break;
        case 27:
            $str = "Cao Thủ";
            break;
        case 28:
            $str = "Thách Đấu";
            break;
        defaut:
            $str = "Chưa Xác Định";
            break;
    }
    return $str;
}


function get_icon_rank($rank)
{
    switch ($rank) {
        case 0:
            $str = "chuarank.jpg";
            break;
        case 1:
            $str = "chuarank.jpg";
            break;
        case 2:
            $str = "dong.jpg";
            break;
        case 3:
            $str = "dong.jpg";
            break;
        case 4:
            $str = "dong.jpg";
            break;
        case 5:
            $str = "dong.jpg";
            break;
        case 6:
            $str = "dong.jpg";
            break;
        case 7:
            $str = "bac.jpg";
            break;
        case 8:
            $str = "bac.jpg";
            break;
        case 9:
            $str = "bac.jpg";
            break;
        case 10:
            $str = "bac.jpg";
            break;
        case 11:
            $str = "bac.jpg";
            break;
        case 12:
            $str = "vang.jpg";
            break;
        case 13:
            $str = "vang.jpg";
            break;
        case 14:
            $str = "vang.jpg";
            break;
        case 15:
            $str = "vang.jpg";
            break;
        case 16:
            $str = "vang.jpg";
            break;
        case 17:
            $str = "bachkim.jpg";
            break;
        case 18:
            $str = "bachkim.jpg";
            break;
        case 19:
            $str = "bachkim.jpg";
            break;
        case 20:
            $str = "bachkim.jpg";
            break;
        case 21:
            $str = "bachkim.jpg";
            break;
        case 22:
            $str = "kimcuong.jpg";
            break;
        case 23:
            $str = "kimcuong.jpg";
            break;
        case 24:
            $str = "kimcuong.jpg";
            break;
        case 25:
            $str = "kimcuong.jpg";
            break;
        case 26:
            $str = "kimcuong.jpg";
            break;
        case 27:
            $str = "caothu.jpg";
            break;
        case 28:
            $str = "thachdau.jpg";
            break;
        defaut:
            $str = "chuarank.jpg";
            break;
    }
    return $str;
}

function auto_get($url){
    $data = curl_init();
    curl_setopt($data, CURLOPT_HEADER, false);
    curl_setopt($data, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($data, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($data, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
    curl_setopt($data, CURLOPT_CONNECTTIMEOUT, 3);
    curl_setopt($data, CURLOPT_TIMEOUT, 3);
    curl_setopt($data, CURLOPT_HTTPHEADER, array('Accept: application/json'));
    curl_setopt($data, CURLOPT_URL, $url);
    $res = curl_exec($data);
    curl_close($data);
    return $res;
}

function in_array_r($needle, $haystack, $strict = false) {
    foreach ($haystack as $item) {
        if (($strict ? $item === $needle : $item == $needle) || (is_array($item) && in_array_r($needle, $item, $strict))) {
            return true;
        }
    }

    return false;
}
function text($string, $separator = ', '){
    $vals = explode($separator, $string);
    foreach($vals as $key => $val) {
        $vals[$key] = strtolower(trim($val));
    }
    return array_diff($vals, array(""));
}

?>