<div class="sa-footer">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-6">
                <div class="sa-ftadd">

                </div>
                <div class="sa-fthotline">
                    <div class="sa-ftarow clearfix">
                        <div class="sa-ftacol sa-fthnum">
                            <p><a href="tel:0169.7369.311" title="">Hotline: 0169.7369.311</a></p>
                            <p><a href="https://www.facebook.com/adminshopacc" title="">Phan Thành Nhân
</a></p>
                        </div>
                        <div class="sa-ftacol sa-fthwork">
                            Thời gian làm việc: <strong>8h-23h</strong> các ngày trong tuần
                        </div>
                    </div>
                </div>
                
            </div>
                    <div class="col-sm-12 col-md-6 hidden-xs">
                <div class="sa-statistics"> 
                    <p>Tổng Acc đã bán ra : <b><?=$giaodich?></b>
                    </p>
                    <p>Acc đang bán : <b><?=$chuaban?></b>
                    </p>
                                        
                    <p>Số lần truy cập : <b>62874</b>
                    </p>
                    <p>Tổng số thành viên : <b><?=$user?></b>
                    </p>
                </div>

                    </div>
        </div>
    </div>
</div>
<style type="text/css">
    button#vl {
    margin-top: -20px;
}
</style>
   <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>

<div class='modal fade' id='myModal'>
            <div class='modal-dialog'>
                <div class='modal-content'>
                    <div class='modal-header'>
                        <h4 class='modal-title' style="color:black">
                         <strong><div style="color:red">Thông báo</div></strong>
                                                                         <button id="vl" type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>

                        </h4>

                    </div>
                    <!-- / modal-header -->
                    <div class='modal-body'>
<p style="color:black"> Lienquan2003.com Chào Qúy Khách - Shop Uy Tín Gía Rẻ - Chất Lượng Các Bạn Nạp Thẻ Viettel Sẽ Được Uư Tiên Duyệt Nhanh Nhất Từ 5p - 30p Thanh Toán Qua ATM / Ví điện tử giảm 20% Thắc Mắc Vui Lòng Liên Hệ Qua Fanpage - Hoặc LH qua Sdt : 01697369311
                    ><img src="https://i.imgur.com/JSIguBS.png"
</p>


                            
                        </p>

                    </div>
                    <!-- / modal-body -->
<!--                   <div class='modal-footer'>
                       <div class="checkbox pull-right">
                            <label>
                              <input class='modal-check' name='modal-check' type="checkbox"> <b style="color:black">Không thấy nữa</b>
                            </label>
                        </div>
                        <!--/ checkbox -->
                  </div>
                  <!--/ modal-footer -->
                </div>
                <!-- / modal-content -->
          </div>
          <!--/ modal-dialog -->
        </div>
        <!-- / modal -->
<script>
    window.fbAsyncInit = function() {
        FB.init({
            appId: '116888982260982',
            xfbml: true,
            version: 'v2.8'
        });
    };

    (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) {
            return;
        }
        js = d.createElement(s);
        js.id = id;
        js.src = "//connect.facebook.net/vi_VN/sdk.js";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));
</script>
<div id="fb-root"></div>
<script>
$(document).ready(function() {
 /* ---------------------------------------------------
        Scroll top 
    --------------------------------------------------- */
      // browser window scroll (in pixels) after which the "back to top" link is shown
    var offset = 300,
    //browser window scroll (in pixels) after which the "back to top" link opacity is reduced
    offset_opacity = 1700,
    //duration of the top scrolling animation (in ms)
    scroll_top_duration = 700,
    //grab the "back to top" link
    $back_to_top = $('.cd-top');

    //hide or show the "back to top" link
    $(window).scroll(function(){
      ( $(this).scrollTop() > offset ) ? $back_to_top.addClass('cd-is-visible') : $back_to_top.removeClass('cd-is-visible cd-fade-out');
      if( $(this).scrollTop() > offset_opacity ) { 
        $back_to_top.addClass('cd-fade-out');
      }
    });

    //smooth scroll to top
    $back_to_top.on('click', function(event){
      event.preventDefault();
      $('body,html').animate({
        scrollTop: 0 ,
        }, scroll_top_duration
      );
    });
});

function alert_acc(acc) {
	swal(
	{
	  title: "Tài Khoản Số #"+acc,
	  text: "Khi bạn mua xong hãy vào phần lịch sử giao dịch để kiểm tra và nhận thông tin tài khoản.\nBạn có chắc chắn muốn mua tài khoản này?",
	  type: "info",
	  showCancelButton: true,
	  confirmButtonColor: "rgb(5, 119, 114)",
          
	  confirmButtonText: "Mua",
          cancelButtonColor: "#AA0000",
	  cancelButtonText: "Không",
	  closeOnConfirm: false,
	  showLoaderOnConfirm: true
	}, function () {
	  $.post("getacc/index.php", {id: acc}, function (data) {
	    if (data.error == 0) {
	      
	     swal({
  title: "Mua acc thành công !",
  text: data.msg,
  type: "success",
  html: true,
  showCancelButton: true,
  confirmButtonColor: "#FFE282",
 cancelButtonColor: "#FFE282",
  confirmButtonText: "OK",
  cancelButtonText: "Xem lịch sử mua",
  showLoaderOnConfirm: true,
  showLoaderOnCancel: true,

},
function(isConfirm){
  if (isConfirm) {
     setTimeout(function () {
    load_account_list();
  }, 20);
  } else {
     setTimeout(function () {
    window.location = "/lich-su-mua";
  }, 20);
  }
});
    
	    } else {
	      swal({
	        title : "Có lỗi xảy ra!!",
	        type: "error",
	        text: data.msg
	      });
	    }
	  }, "json");
	}
	);
}

</script> 
 

<script type="text/javascript">
    $(window).load(function(){
        $('#myModal').modal('show');
    });
</script>
<script type="text/javascript">
    (function () {
        var options = {
            facebook: "2060157530939194", // Facebook page ID
            company_logo_url: "//scontent.fsgn2-3.fna.fbcdn.net/v/t1.0-9/17191225_1267997259953847_5526010380846532961_n.jpg?oh=4ddacc9b28160079a98d2b3d6f1061f3&oe=5A3DFB0A",
            greeting_message: "Chào mừng bạn đến với Lienquan2003.Com !\nBạn cần hỗ trợ gì không ? Nhắn tin cho mình nhé !", 
            call_to_action: "Chào bạn ! Bạn cần hỗ trợ gì không ?",
            position: "right",
        };
        var proto = document.location.protocol, host = "whatshelp.io", url = proto + "//static." + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>
<script>
  window.fbAsyncInit = function() {
    FB.init({
      appId            : '2060157530939194',
      autoLogAppEvents : true,
      xfbml            : true,
      version          : 'v2.11'
    });
  };
  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "https://connect.facebook.net/vi_VN/sdk.js";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));
</script>
</body> 
</html>
</style>