<?php 
     /*


     */
	require_once 'src/Facebook/autoload.php';
	session_start();
	$fb = new Facebook\Facebook([
	  	'app_id' => '624798471282135',
	  	'app_secret' => '6693e1ff4f6fbbaac0d5ee559b5c5be2',
	  	'default_graph_version' => 'v2.9',
	  	'default_access_token' => isset($_SESSION['facebook_access_token']) ? $_SESSION['facebook_access_token'] : '624798471282135|6693e1ff4f6fbbaac0d5ee559b5c5be2'
	]);
	
?>