<div class="sa-banner">
      <div class="container">
        <div class="sa-bntab clearfix">
          <div class="sa-bncol2">
            <div class="swiper-container sabner">
              <div class="swiper-wrapper">
                <div class="swiper-slide">
                      <!--<div class="embed-container"><iframe src="https://www.youtube.com/embed/o_O8k_yhbqg" frameborder="0" allowfullscreen=""></iframe></div>-->
                    <img src="https://s2.anh.im/2018/07/27/ShopGameLQM.VN38abcd08e957506e.png">
                </div>
        </div>
                    </div>
                </div>
         </a><div class="sa-bncol1">
                    <div class="sa-bntbox">
                        <ul class="sa-bnnav-tabs" role="tablist">
                            <li role="presentation" class="active"><a href="#topnap" role="tab" data-toggle="tab">Top nạp thẻ</a>
                            </li>
                            <li role="presentation" class=""><a href="#thuong" role="tab" data-toggle="tab">Phần thưởng</a>
                            </li>
                        </ul>
              <div class="sa-bntcbox tab-content">
                <div role="tabpanel" class="tab-pane active" id="topnap">
                  <div class="sa-bntabbox mcustomscrollbar">
                    <ul class="sa-topthe">
                       <?php
                        $i=1;
$cash = mysql_query("SELECT * FROM `top` WHERE `ucash` >= '10000' order by ucash desc LIMIT 5");
if (mysql_num_rows($cash) == 0):
?>
<li><p>Chưa có ai đứng top</p></li>
<?php else: while ($row = mysql_fetch_array($cash, MYSQL_ASSOC)):?>
<li>
<i><?=$i?></i>
<span><a href="https://facebook.com/<?=$row['uid']?>"><?=$row['uname']?></a></span>
<label><?=number_format($row['ucash'], 0, '.', '.')?><sup>đ</sup>
</label>
</li>
<?php $i++; endwhile; endif; ?> 
                      
                                          </ul>
                  </div>
                </div>
                <div role="tabpanel" class="tab-pane " id="thuong">
                  <div class="sa-bntabbox mcustomscrollbar">
                    <ul class="sa-pthuong">
                      <li>
                        <label><strong>TOP 1:</strong> Thẻ Cào 100.000 VNĐ</label>
                      </li>
                      <li>
                        <label><strong>TOP 2:</strong> 80.000 VNĐ trên web shop</label>
                      </li>
                      <li>
                        <label><strong>TOP 3:</strong> 70.000 VNĐ trên web shop</label>
                      </li>
                      <li>
                        <label><strong>TOP 4:</strong> 60.000 VNĐ trên web shop</label>
                      </li>
                      <li>
                        <label><strong>TOP 5:</strong> 50.000 VNĐ trên web shop</label>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>   
</br>   
   
   
   <div class="sa-mainsa">
    <div class="container">
        <div class="sa-lprod">
            <div class="sa-lpmain">
                <div class="sa-lsnmain clearfix">
                    <div class="sa-ls-table table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <td>STT</td>
                                    <td>Tên</td>
                                    <td>Tên tài khoản</td>
                                    <td>Mật khẩu</td>
                                    <td>Giá</td>
                                    <td>Ngày mua</td>
                                </tr>
                            </thead>
                            <tbody>
<?php
$i=1;$giaodichx = mysql_query("SELECT * FROM `lichsumua` WHERE `uid` = '".$uid."' order by id desc");
if (mysql_num_rows($giaodichx) == 0):
?>
<tr><td colspan="6" class="text-center"><p>Bạn Chưa Có Cuộc Giao Dịch Nào</p></td></tr>
<?php else: while ($row = mysql_fetch_array($giaodichx, MYSQL_ASSOC)):?>
<tr>
<td class="text-primary"><?=$i?></td><td class="text-primary">Tài khoản <?=$row['loainick']?> #<?=$row['idacc']?></td>
<td class="text-primary"><?=$row['taikhoan']?></td><td class="text-primary"><?=$row['matkhau']?></td> 
<td class="text-primary"><?=$row['price']?></td><td class="text-primary"><?=$row['date']?></td>
</tr>
<?php $i++; endwhile; endif; ?>

                           </tbody>
                        </table>
                    </div>
                </div>
                            </div>
        </div>
    </div>
</div>

</br>