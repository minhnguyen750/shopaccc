<style>

.ui.masthead.segment.he-store::before {
    background: url('assets/images/shoplmht-lol-skin-shop-header.jpg');
    background-position: 50% 20%!important;
    background-size: cover!important;
}

#skin-page-information {
    background: #262626;
}

.ui.card, .ui.cards>.card {
  background: transparent;
}

.ui.cards a.card:hover, .ui.link.card:hover, .ui.link.cards .card:hover, a.ui.card:hover {
    cursor: pointer;
    z-index: 5;
    background: transparent;
    border: none;
    box-shadow: 0 0 0 0 transparent;
    -webkit-transform: translateY(-3px);
    transform: translateY(-3px);
}

</style>
<?php 
$json = auto_get('https://shopacctoan.net/Content/kiendeptrai.txt');
$rp_data = auto_get('https://shoapcctoan.net/Content/data_rp.txt');
$json_data = json_decode($json, true);
$skin = text($query["skins"]);
$champ = text($query["champs"]);

?>
<div class="sa-mainsa">
    <div class="container">
        <div class="sa-lprod">
            <div class="sa-lpmain">
                <div class="sa-lsnmain clearfix">
                <ul class="sa-brea">
                        <li><a href="/" title="Trang Chủ">Trang Chủ</a></li>
                        <li class="active"><a href="javascript:;" title="Tài Khoản #<?=$query['id']?> - <?=get_string_rank($query['rank'])?> - <?=get_string_khung($query['khung'])?> - <?=$query['count_champ']?> Tướng - <?=$query['count_skin']?> Skin">Acc Liên Quân #<?=$query['id']?> - <?=get_string_rank($query['rank'])?> - <?=get_string_khung($query['khung'])?> - <?=$query['count_champ']?> Tướng - <?=$query['count_skin']?> Skin</a></li>
                    </ul>
                    <div class="sa-ttacc">
                        <div class="sa-ttactit clearfix">
                            <h1 class="sa-ttacc-tit">Tài Khoản #<?=$query['id']?> - <?=get_string_rank($query['rank'])?> - <?=get_string_khung($query['khung'])?></h1>
                            <ul class="sa-ttactul">
                                                                <li class="sa-ttac-pri"><?=number_format($query['gia'], 0, '.', '.')?><sup>đ</sup></li>                              
                                <li class="sa-ttac-btn"><a class="ac-buy-acc" onclick="alert_acc(<?=$query['id']?>); return false;" data-id="<?=$query['id']?>">MUA NGAY</a></li>
                                <!--<div class="ui massive blue button"  onclick="alert_acc(<?=$query['id']?>);" >Mua Ngay</div> -->
                                                            </ul>
                        </div>
                        <ul class="sa-ttacc-tabs clearfix" role="tablist">
                            <li role="presentation" class="active"><a href="#ct-thong-tin" role="tab" data-toggle="tab">THÔNG TIN</a></li> 

                            
                                                      <!--  <li role="presentation">
                                <a href="#ct-ngoc-bo-tro" role="tab" data-toggle="tab">
                                    NGỌC HỖ TRỢ
                                        <span>0</span>
                                </a>
                            </li> -->
                                                    </ul>
                        <div class="ui hidden divider"></div>
		 
	<div class="swiper-container ccc swiper-container-horizontal">
                    <div class="swiper-wrapper" style="transform: translate3d(0px, 0px, 0px); transition-duration: 0ms;">

			
<?php $image = explode("|",$query['hinhanh']); ?>
<?php foreach($image as $row): ?>
 <div class="swiper-slide" style="width: 100%; margin-right: 5px;">
                                <a>
                                    <img style="width: 100%; border: 3px solid #948159;" src="<?=$row?>">
                                </a>
                            </div>
<?php endforeach; ?>											                            
											                    </div>
											                    
											                    
											                    
											                    
											                    
                    <div class="swiper-button-prev swiper-button-white swiper-button-disabled"></div>
                    <div class="swiper-button-next swiper-button-white"></div>
                    <div class="swiper-pagination swiper-pagination-clickable swiper-pagination-bullets"><span class="swiper-pagination-bullet swiper-pagination-bullet-active"></span><span class="swiper-pagination-bullet"></span><span class="swiper-pagination-bullet"></span><span class="swiper-pagination-bullet"></span></div>
                </div>
                
<div class="sa-ttmore">
                        <h2 class="sa-ttmoretit" style="color: #FFFFFF">ACC CÙNG ĐƠN GIÁ</h2>
                        <div class="swiper-container sattmore swiper-container-horizontal">
                
                <?php
$result = mysql_query("SELECT * FROM `baidang` where `gia` = '".$query['gia']."' AND `trangthai`!='off' AND `loainick`='LQ'  order by time DESC LIMIT 4");
while ($row = mysql_fetch_array($result, MYSQL_ASSOC)): ?>

                <div class="sa-lpcol">
                        <div class="sa-lpi" style="border-image: url(/assets/img/khung/diamond.png) 25 round;">                            <a class="sa-lpimg" href="/account/68">
                            </a><a class="sa-lpimg" href="/acc-lq-rank-vang-gia-re-5500000-62.html">
                                 
                                <h3><span class="sa-lpcode">#<?=$row['id']?> - <?=get_string_rank($row['rank'])?></span></h3>
                                                                <p class="sa-lpping"><img src="<?=$row['thumb']?>">
                                </p>
                                                                    
                            <div class="sa-lpinfo">
                                <div class="sa-lpits mcustomscrollbar">

                                    <br>
                                    ● Rank: <?=get_string_rank($row['rank'])?><br>
                                    
                                                                        ● Tướng: <?=$row['count_champ']?><br>
                                    ● Trang Phục: <?=$row['count_bangngoc']?><br>
                                    ● Bảng Ngọc: <?=$row['count_bangngoc']?><br>
                                                            </div>
                                                          
                        </div>     
                                 

                            </a>
                            <div class="sa-lpbott clearfix">
                                                                    
                                <div class="gg-info">
                                    <div class="gg-lpbif"> <p class="hero"> Tướng: <?=$row['count_champ']?> <br> </p><p class="skin"> Skin: <?=$row['count_skin']?></p></div>
                                   
                                    <div class="gg-lpbpri"> <p class="hero"> Ngọc: <?=$row['count_bangngoc']?> <br> </p><p class="skin"> Giảm giá: 0% </p></div>
                                </div>
                                 
                                <div class="sa-lpbif" style="    text-align: left;">
                                                                        <p class="sa-lpbpice">4,400,000<sup>ATM</sup></p>

                                                                                                        
                                    <a href="/acc-<?=$row['id']?>" class="xem-acc" title="XEM ACC">XEM ACC</a>
                                                                    </div>

                                <div class="sa-lpbpri">
                                    <p class="sa-lpbpice"><?=number_format($row['gia'], 0, '.', '.')?><sup>CARD</sup></p>
                                    <p></p>
                                     
                                    <a id="button_mua" class="sa-lpbbtn ac-buy-acc" data-price="5500000" title="MUA NGAY" data-id="62" title="MUA NGAY">MUA NGAY</a>
                                    
                                                                </div>
                            </div>
                        </div>
                    </div>
                
  <?php endwhile; ?>              
                
				<script>
	var mySwiper = new Swiper('.swiper-container', {
     preventClicks: false,
                paginationClickable: true,
                pagination: '.sabner .swiper-pagination',
                nextButton: '.sabner .swiper-button-next',
                prevButton: '.sabner .swiper-button-prev',
                spaceBetween: 5,
                centeredSlides: true,
                autoplay: 2500,
                autoplayDisableOnInteraction: false
});
	</script>		
		</div>    
		
  </div>


<style>

.buttonfacebook {
    background-color: #3b5998;
    color: white;
    float: left;
    height: 50px;
    line-height: 50px;
    margin-left: 0;
    padding-left: 20px;
    position: relative;
    text-align: center;
    width: 200px;
}
	.buttoncall {
    background-color: #b8312f;
    color: white;
    float: left;
    height: 50px;
    line-height: 50px;
    margin-left: 0;
    padding-left: 20px;
    position: relative;
    text-align: center;
    width: 200px;
}
</style>






<script>

function muatructiep(){
    $('.small.modal')
  .modal('show');
}

$(document).ready(function() {

      // On input of the searchbar
    $("#account-skin-searchbar").on("input", function(){
      // Get the input of the searchbar, trim it and convert to lowercase
      var query = $.trim($("#account-skin-searchbar").val()).toLowerCase();

      // Loop all images
      $(".skin-search-image-id").each(function(){

        var $this = $(this);
        // Get current skinname from the alt tag, convert it and trim it
        var currentSkin = $.trim($(this).attr("alt")).toLowerCase();
        
        // If the input contains our skinname
        if(currentSkin.indexOf(query) === -1){
          $this.parent().addClass("skin-search-image-id");
        } else {
          $this.parent().removeClass("skin-search-image-id");
        }
      });
    });

});



</script>