    <div class="sa-mainsa">
    <div class="container">
        <div class="sa-lprod">
            <div class="sa-lpmain">
                <div class="sa-lsnmain clearfix">
                    <div class="sa-ttshop">
                          <h4 class="modal-title">Hướng dẫn bảo mật tài khoản</h4>
      </div>
      <div class="modal-body">
        <p style="text-align: justify;"><strong>Vì tài khoản Garena của bạn có thể sử dụng mọi dịch vụ của Garena nên việc bảo vệ tài khoản này bằng email hoặc điện thoại di động là việc hết sức cần thiết.&nbsp;</strong><strong>Hãy làm theo những bước sau để đảm bảo an toàn cho tài khoản của bạn.</strong></p>
<p style="text-align: justify;"><strong></strong></p>
 
<p>&nbsp;</p>
<h5 style="text-align: justify;">Xác nhận email</h5>
<p style="text-align: justify;">Để tạo một tài khoản Garena, bạn cần phải có hòm thư điện tử (email) và để đảm bảo an toàn, hãy xác thực hòm thư điện tử của bạn theo các bước sau:</p>
<p style="text-align: justify;">Truy cập trang <a href="http://taikhoan.garena.vn">http://taikhoan.garena.vn</a>&nbsp;- Đăng nhập nick Garena của bạn.</p>
<p style="text-align: justify;">Bước 1: Nhấp chuột vào chữ "Xác nhận" ở dòng Email.</p>
<h6 style="text-align: justify;"><img src="https://lienminh.garena.vn/images/articles/SieuNhan.SamSet/bao_mat_tai_khoan/email.JPG" width="500" height="278" alt="email" style="display: block; margin-left: auto; margin-right: auto;" /></h6>
<p style="text-align: justify;">Sau đó đăng nhập tài khoản của bạn</p>
<h6 style="text-align: justify;"><img src="https://lienminh.garena.vn/images/articles/SieuNhan.SamSet/bao_mat_tai_khoan/dang_nhap.jpg" width="500" height="195" alt="dang nhap" style="display: block; margin-left: auto; margin-right: auto;" /></h6>
<p style="text-align: justify;">Bước 2: Điền đầy đủ những thông tin bạn còn thiếu.</p>
<h6 style="text-align: justify;"><img src="https://lienminh.garena.vn/images/articles/SieuNhan.SamSet/bao_mat_tai_khoan/dienthongtin.jpg" width="500" height="299" alt="dienthongtin" style="display: block; margin-left: auto; margin-right: auto;" /></h6>
<p style="text-align: justify;">Sau đó, màn hình sẽ hiển thị cửa sổ xác nhận như dưới đây.</p>
<h6 style="text-align: justify;"><img src="https://lienminh.garena.vn/images/articles/SieuNhan.SamSet/bao_mat_tai_khoan/xac_nhan.jpg" width="500" height="197" alt="xac nhan" style="display: block; margin-left: auto; margin-right: auto;" /></h6>
<p style="text-align: justify;">Bước 3: Truy cập vào hòm thư điện tử của bạn vào nhấp vào đường dẫn kích hoạt.</p>
<h6 style="text-align: justify;"><img src="https://lienminh.garena.vn/images/articles/SieuNhan.SamSet/bao_mat_tai_khoan/link_xac_nhan.jpg" width="500" height="94" alt="link xac_nhan" style="display: block; margin-left: auto; margin-right: auto;" /></h6>
<p style="text-align: justify;">Khi kích hoạt thành công, màn hình của bạn sẽ hiển thị như sau:</p>
<p style="text-align: justify;"><img src="https://lienminh.garena.vn/images/articles/SieuNhan.SamSet/bao_mat_tai_khoan/thanh_cong.jpg" width="500" height="64" alt="thanh cong" style="display: block; margin-left: auto; margin-right: auto;" /></p>
<h5 style="text-align: justify;">Đăng kí số điện thoại</h5>
<p style="text-align: justify;">Bước 1: Nhấp chuột vào chữ "Thêm" ở dòng "Điện thoại".</p>
<h6 style="text-align: justify;"><img src="https://lienminh.garena.vn/images/articles/SieuNhan.SamSet/bao_mat_tai_khoan/dienthoai.jpg" width="500" height="262" alt="dienthoai" style="display: block; margin-left: auto; margin-right: auto;" /></h6>
<p style="text-align: justify;">Bước 2: Hệ thống sẽ yêu cầu bạn nhập số điện thoại (ô màu đỏ). Sau khi nhập xong số điện thoại, chọn ô "Gửi mã" (ô màu xanh).</p>
<p style="text-align: justify;">Lúc này sẽ có một mã xác nhận được gửi tới điện thoại của bạn. Nhập mã số nhận được vào ô "Mã" (ô màu đen). Và chọn nút "Xác nhận".</p>
<h6><img src="https://lienminh.garena.vn/images/articles/SieuNhan.SamSet/bao_mat_tai_khoan/nhap_so_dienthoai.jpg" width="500" height="359" alt="nhap so_dienthoai" style="display: block; margin-left: auto; margin-right: auto;" /></h6>
<p>Bước 3: Hệ thống sẽ yêu cầu bạn cài đặt 2 bước xác nhận. Hãy chọn "Bật 2 bước xác nhận".</p>
<h6><img src="https://lienminh.garena.vn/images/articles/SieuNhan.SamSet/bao_mat_tai_khoan/2_buoc_xac_nhan.jpg" width="500" height="163" alt="2 buoc_xac_nhan" style="display: block; margin-left: auto; margin-right: auto;" /></h6>
<p>Sau khi kích hoạt xong là bạn đã đăng kí số điện thoại thành công. Mỗi khi có yêu cầu thay đổi mật khẩu, hệ thống sẽ gửi tin nhắn về điện thoại di động của bạn. Hãy bảo mật tài khoản của bạn thật cẩn thận nhé!</p>

                            <div>&nbsp;</div>

                            <div>&nbsp;</div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
