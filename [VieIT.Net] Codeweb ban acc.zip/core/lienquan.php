<div class="sa-banner">
        <div class="container">
            <div class="sa-bntab clearfix">
                <div class="sa-bncol2">
                    <div class="swiper-container sabner">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                            <iframe width="860" height="375" src="https://www.youtube.com/embed/CxXN5DmI9s4?" frameborder="0" allowfullscreen></iframe>
                            </div>
        </div>
                    </div>
                </div>
         </a><div class="sa-bncol1">
                    <div class="sa-bntbox">
                        <ul class="sa-bnnav-tabs" role="tablist">
                            <li role="presentation" class="active"><a href="#topnap" role="tab" data-toggle="tab">Top nạp thẻ</a>
                            </li>
                            <li role="presentation" class=""><a href="#thuong" role="tab" data-toggle="tab">Phần thưởng</a>
                            </li>
                        </ul>
              <div class="sa-bntcbox tab-content">
                <div role="tabpanel" class="tab-pane active" id="topnap">
                  <div class="sa-bntabbox mcustomscrollbar">
                    <ul class="sa-topthe">
                       <?php
                        $i=1;
$cash = mysql_query("SELECT * FROM `top` WHERE `ucash` >= '10000' order by ucash desc LIMIT 5");
if (mysql_num_rows($cash) == 0):
?>
<li><p>Chưa có ai đứng top</p></li>
<?php else: while ($row = mysql_fetch_array($cash, MYSQL_ASSOC)):?>
<li>
<i><?=$i?></i>
<span><a href="https://facebook.com/<?=$row['uid']?>"><?=$row['uname']?></a></span>
<label><?=number_format($row['ucash'], 0, '.', '.')?><sup>đ</sup>
</label>
</li>
<?php $i++; endwhile; endif; ?> 
                      
                                          </ul>
                  </div>
                </div>
                <div role="tabpanel" class="tab-pane " id="thuong">
                  <div class="sa-bntabbox mcustomscrollbar">
                    <ul class="sa-pthuong">
                      <li>
                        <label><strong>TOP 1:</strong> Thẻ Cào 100.000 VNĐ</label>
                      </li>
                      <li>
                        <label><strong>TOP 2:</strong> 80.000 VNĐ trên web shop</label>
                      </li>
                      <li>
                        <label><strong>TOP 3:</strong> 70.000 VNĐ trên web shop</label>
                      </li>
                      <li>
                        <label><strong>TOP 4:</strong> 60.000 VNĐ trên web shop</label>
                      </li>
                      <li>
                        <label><strong>TOP 5:</strong> 50.000 VNĐ trên web shop</label>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <br>
<script src="/Content/js/Custom/ffilter1.js"></script>
<div class="sa-mainsa">
    
                       <div class="sa-lpi">
           <div class="sa-lprod">
               
            
               
<div class="sa-lprod">
                      <div class="row">
                <div class="col-sm-4 text-center" style="margin-right: -11px; margin-left: 11px;">
                    <a class=" button btn btn-danger" type="button" href="/lien-quan.html">Tài Khoản LQ </a>
                    <a class=" button btn btn-default" type="button" href="/random.html">Thử Vận May</a>
                </div>
                <div class="col-sm-8">
                    <marquee scrollamount="4"><img width="36" height="36" src="https://www.shopacclm247.vn/assets/images/run.gif" longdesc="36"> 
                    <?php
                     $cash = mysql_query("SELECT * FROM `lichsumua` order by id desc LIMIT 15");
                     while ($row = mysql_fetch_array($cash, MYSQL_ASSOC)){
                     ?>
                    <a href="" target="_blank"><span class="text-success"><?=$row['name']?></span></a> Mua tài khoản<span style="color: yellow;" > Liên Quân #<?=$row['idacc']?></span> với giá <span style="color: yellow;" ><?=number_format($row['price'])?></span><sup class="text-muted">vnđ</sup> <?php $time_agoa = strtotime($row['date']);
									echo time_stamp($time_agoa); ?> -  
									
									<?php
									}
									?>
									</marquee>

                </div>
            </div>
        </div>
           </div>
        </div>
        <div class="sa-lprod">
            <div class="sa-filter">
                <span class="sa-filic"><i class="glyphicon glyphicon-filter"></i> LỌC THEO</span>
                <div class="sa-filbox">
                    <div class="dropdown" data-filter="tim-theo-rank">
                        <button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                        Tìm Theo Rank <span class="caret"></span>
                        </button>
                        <ul class="dropdown-menu select">
                            <li onclick="rank=1;"><a href="javascript:;" class="acfiit">Tất Cả</a></li>
                            <li onclick="rank=0;"><a href="javascript:;" class="acfiit">Chưa rank</a></li>
                            <li onclick="rank=2;"><a href="javascript:;" class="acfiit">Rank Đồng</a></li>
                            <li onclick="rank=3;"><a href="javascript:;" class="acfiit">Rank Bạc</a></li>
                            <li onclick="rank=4;"><a href="javascript:;" class="acfiit">Rank Vàng</a></li>
                            <li onclick="rank=5;"><a href="javascript:;" class="acfiit">Rank Bạch Kim</a></li>
                            <li onclick="rank=6;"><a href="javascript:;" class="acfiit">Rank Kim Cương</a></li>
                            <li onclick="rank=7;"><a href="javascript:;" class="acfiit">Rank Cao Thủ</a></li>
                            <li onclick="rank=8;"><a href="javascript:;" class="acfiit">Rank Thách Đấu</a></li>
                        </ul>
                    </div>
                    <div class="dropdown" data-filter="tim-theo-gia">
                        <button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                        Tìm Theo Giá <span class="caret"></span>
                        </button>
                        <ul class="dropdown-menu select">
                            <li onclick="price=1;"><a href="javascript:;" class="acfiit">Từ 50k trờ xuống</a></li>
                            <li onclick="price=2;"><a href="javascript:;" class="acfiit">Từ 50k đến 100k</a></li>
                            <li onclick="price=3;"><a href="javascript:;" class="acfiit">Từ 100k đến 300k</a></li>
                            <li onclick="price=4;"><a href="javascript:;" class="acfiit">Từ 300k đến 500k</a></li>
                            <li onclick="price=5;"><a href="javascript:;" class="acfiit">Từ 500k đến 700k</a></li>
                            <li onclick="price=6;"><a href="javascript:;" class="acfiit">Từ 700k đến 1 triệu</a></li>
                            <li onclick="price=7;"><a href="javascript:;" class="acfiit">Từ 1 triệu trở lên</a></li>
                        </ul>
                    </div>
                    <div class="dropdown" data-filter="sap-xep">
                    <button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Sắp Xếp <span class="caret"></span>
                    </button>
                    <ul class="dropdown-menu select">
                        <li onclick="order=1;"><a href="javascript:;" class="acfiit">Tướng nhiều nhất</a></li>
                        <li onclick="order=2;"><a href="javascript:;" class="acfiit">Trang phục nhiều nhất</a></li>
                    </ul>
                </div>
                    <button class="sa-ftbtndel btn btn-default">XÓA<i class="glyphicon glyphicon-remove"></i></button>
                </div>
            </div>
            <div class="sa-lpmain">
                <div class="sa-lprow clearfix">


<?php 

/* config page */
if (isset($_POST["page"])) { $page  = $_POST["page"]; } else { $page=1; }; 
$num_rec_per_page=20;
$start_from = ($page-1) * $num_rec_per_page;  
$i=0; 


if (isset($_POST["order"]) && $_POST["order"]=='1'):// nhiều tướng
$result = mysql_query("SELECT * FROM `baidang` where $sql_gia $sql_rank $sql_khung `trangthai`!='off' AND `loainick` = 'LQ' order by `count_champ` DESC LIMIT $start_from, $num_rec_per_page");
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `baidang` WHERE $sql_gia $sql_rank $sql_khung `trangthai`!='off' AND `loainick` = 'LQ'"), 0);
elseif (isset($_POST["order"]) && $_POST["order"]=='2'):// nhiều skin
$result = mysql_query("SELECT * FROM `baidang` where $sql_gia $sql_rank $sql_khung `trangthai`!='off' AND `loainick` = 'LQ' order by `count_skin` DESC LIMIT $start_from, $num_rec_per_page");
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `baidang` WHERE $sql_gia $sql_rank $sql_khung `trangthai`!='off'AND `loainick` = 'LQ'"), 0);
else:// không lọc
$result = mysql_query("SELECT * FROM `baidang` where $sql_gia $sql_rank $sql_khung `trangthai`!='off' AND `loainick` = 'LQ' order by time DESC LIMIT $start_from, $num_rec_per_page");
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `baidang` WHERE $sql_gia $sql_rank $sql_khung `trangthai`!='off'AND `loainick` = 'LQ'"), 0);
endif;
$total_pages = ceil($tong / $num_rec_per_page);
if($tong > 0):
while ($row = mysql_fetch_array($result, MYSQL_ASSOC)): ?>
 

<div class="sa-lpcol">
                        <div class="sa-lpi" style="border-image: url(/assets/img/khung/diamond.png) 25 round;">                            <a class="sa-lpimg" href="/account/68">
                            </a><a class="sa-lpimg" href="/acc-<?=$row['id']?>">
                                 
                                <h3><span class="sa-lpcode">#<?=$row['id']?> - <?=get_string_rank($row['rank'])?></span></h3>
                                                                <p class="sa-lpping"><img src="<?=$row['thumb']?>">
                                </p>
                                                                    
                            <div class="sa-lpinfo">
                                <div class="sa-lpits mcustomscrollbar">

                                    <br>
                                    ● Rank: <?=get_string_rank($row['rank'])?><br>
                                    
                                                                        ● Tướng: <?=$row['count_champ']?><br>
                                    ● Trang Phục: <?=$row['count_bangngoc']?><br>
                                    ● Bảng Ngọc: <?=$row['count_bangngoc']?><br>
                                                            </div>
                                                          
                        </div>     
                                 

                            </a>
                            <div class="sa-lpbott clearfix">
                                                                    
                                <div class="gg-info">
                                    <div class="gg-lpbif"> <p class="hero"> Tướng: <?=$row['count_champ']?> <br> </p><p class="skin"> Skin: <?=$row['count_skin']?></p></div>
                                   
                                    <div class="gg-lpbpri"> <p class="hero"> Ngọc: <?=$row['count_bangngoc']?> <br> </p><p class="skin"> Giảm giá: 0% </p></div>
                                </div>
                                 
                                <div class="sa-lpbif" style="    text-align: left;">
                                                                        <p class="sa-lpbpice"><?=number_format($row['atm'], 0, '.', '.')?><sup>ATM</sup></p>

                                                                                                        
                                    <a href="/acc-<?=$row['id']?>" class="xem-acc" title="XEM ACC">XEM ACC</a>
                                                                    </div>

                                <div class="sa-lpbpri">
                                    <p class="sa-lpbpice"><?=number_format($row['gia'], 0, '.', '.')?><sup>CARD</sup></p>
                                    <p></p>
                                     
                                    <a id="button_mua" class="sa-lpbbtn ac-buy-acc" onclick="alert_acc(<?=$row['id']?>); return false;" class="sa-lpbbtn ac-buy-acc" title="MUA NGAY">MUA NGAY</a>
                                    
                                                                </div>
                            </div>
                        </div>
                    </div>
            

<?php if($i==3):?>
<div class="clearfix"></div> 
<?php elseif($i==7):?>
<div class="clearfix"></div> 
<?php elseif($i==11):?>
<div class="clearfix"></div> 
<?php endif; ?>

<?php $i++;  endwhile; ?>


                                </div>
<ul class="sa-pagging">
<li onclick="page=1;" class="PagedList-skipToFirst"><a href="?page=1">««</a></li>
<?php
for ($i=1; $i<=$total_pages; $i++) { 

if($_POST['page']==$i):
echo "<li onclick='page=$i;' class='active'><a href='?page=$i'>".$i."</a></li>";
else:
echo "<li onclick='page=$i;'><a href='?page=$i'>".$i."</a></li>";
endif;

}; 

?>
<li onclick="page=<?=$total_pages?>;" class="PagedList-skipToLast"><a href="?page=<?=$total_pages?>">»»</a></li>
</ul>
<?php else: ?>
<h3 class="text-center">Không Có Tài Khoản Nào Được Tìm Thấy</h3>
<?php endif; ?>


            </div>
            <div id="loading" style="display: none; text-align: center; margin-bottom: 30px;">
                <img src="/Content/images/loading.gif">
            </div>
        </div>
    </div>
</div>