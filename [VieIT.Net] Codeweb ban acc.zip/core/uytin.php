            <div class="main"><div class="content_top">
                <div style="padding: 0;" class="container back-ground-color-container">
                    <div style="padding: 0 20px;"><div class="row" id="topup">
                        <h2 class="details-title">DANH SÁCH THÀNH VỪA VIÊN MUA NICK TẠI SHOPTHAIMINH.COM</h2>
                        <hr>
                        </div>
<?php
$i=1;$giaodichx = mysql_query("SELECT * FROM `lichsumua` WHERE `uid` = '".$uid."' order by id desc");
if (mysql_num_rows($giaodichx) == 0):
?>
<tr><td colspan="6" class="text-center"><p>Bạn Chưa Có Cuộc Giao Dịch Nào</p></td></tr>
<?php else: while ($row = mysql_fetch_array($giaodichx, MYSQL_ASSOC)):?>
<p><?=$i?>. <!--<img src='/assets/img/icon/6.gif'/>--> Thành viên <a target='_blank' href='https://fb.com/<?=$row['uid']?>'>
    <img src='https://graph.facebook.com/<?=$row['uid']?>/picture' style='height: 25px;'/> <?=$row['name']?></a> đã mua tài khoản  
    <a target='_blank' href='<?=$home?>/acc-<?=$row['idacc']?>'>#<?=$row['id']?></a>, <?=get_string_rank($row['data_rank'])?> , <?=get_string_khung($row['data_khung'])?>, <?=$row['data_champ']?> Tướng, <?=$row['data_skin']?> Skin với giá: <?=number_format($row['price'])?> đ</p><hr/>
<?php $i++; endwhile; endif; ?> 
</div> 