    <div class="sa-mainsa">
        <div class="container">
		<div class="sa-logmain sa-themain">
            <div class="row">
                <div class="col-md-12">


        <div class="panel-body">
<div class="col-sm-4 col-md-8">
            <form action="paycard" method="post" class="form-horizontal">

                <div class="form-group">
                    <label  for="card_type_id" class="col-sm-3 control-label">
                         CHỌN LOẠI THẺ
                    </label>
                    <div class="col-sm-9">
                        <select name="type" class="form-control">
                            <option  value="0">Chọn Loại Thẻ ( ƯU TIÊN VIETTEL ) </option>
                                <option  value="viettel">VIETTEL </option>
    <option  value="mobi">MOBIFONE </option>
    <option  value="vina">VINAPHONE</option>
   
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label  for="serial" class="col-sm-3 control-label">
                        Nhập Đúng Serial
                    </label>
                    <div class="col-sm-9">
                        <input type="text" name="serial" class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <label  for="code" class="col-sm-3 control-label">
                        Nhập Đúng Mã Thẻ
                    </label>
                    <div class="col-sm-9">
                        <input type="text" name="code" class="form-control">
                    </div>
                </div>

<div class="form-group">
      <label for="card_type_i1d">Mệnh Giá  :</label>

                                     <select name="menhgia" class="form-control">
                                          <option value="">Chọn Mệnh Giá</option>
                                          <option value="10000">10,000 VND</option>
                                          <option value="20000">20,000 VND</option>
                        		          <option value="50000">50,000 VND</option>
                        		          <option value="100000">100,000 VND</option>
                        		          <option value="200000">200,000 VND</option>
                        		          <option value="500000">500,000 VND</option>

                                                </select>


                             </div>
                <div class="form-group">
                    <div class="col-sm-12 text-center">
                        <button type="submit" id="paycard" class="btn btn-primary">Nạp Thẻ</button>
						<button type="reset" class="btn btn-primary">Nhập Lại</button>
                    </div>
                </div>
              
            </form>
			
        </div>
		<div class="col-md-4">
                                <div class="sa-proportion">
                                    <div class="sa-ls-table table-responsive">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <td>100.000 CARD = 100.000 SHOP</td>
                                                </tr>
                                                <tr>
                                                    <td>VUI LÒNG CHỜ DUYỆT THẺ 5>1h</td>
                                                </tr>
                                                <tr>
                                                    <td>CHỌN SAI MỆNH GIÁ TRỪ 50%</td>
                                                </tr>

                                            </thead>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    

            </div>

        </div>
    </div>
</div>

    </div>
<script>
$('#paycard').click(function() {
$('#paycard').addClass('loading');
$('#paycard').prop('disabled', true);
var formData = {
            'type'              : $('select[name=type]').val(),
            'serial'             : $('input[name=serial]').val(),
            'code'    : $('input[name=code]').val(),
                        'menhgia'    : $('select[name=menhgia]').val()

        };
	  $.post("../Content/ajax/site/banthe.php", formData,
              function (data) {
	      swal({
	        title : data.title,
	        type: data.status,
	        text: data.msg
	      });
			$('#paycard').removeClass('loading');
			$('#paycard').prop('disabled', false);
	  }, "json");
});
</script>