  <style>

.ui.masthead.segment.he-store::before {
    background: url('assets/images/shoplmht-lol-skin-shop-header.jpg');
    background-position: 50% 20%!important;
    background-size: cover!important;
}

#skin-page-information {
    background: #262626;
}

.ui.card, .ui.cards>.card {
  background: transparent;
}

.ui.cards a.card:hover, .ui.link.card:hover, .ui.link.cards .card:hover, a.ui.card:hover {
    cursor: pointer;
    z-index: 5;
    background: transparent;
    border: none;
    box-shadow: 0 0 0 0 transparent;
    -webkit-transform: translateY(-3px);
    transform: translateY(-3px);
}

</style>

  <div class="ui inverted vertical masthead center aligned segment he-store">

    <div class="ui center aligned container">
 

      <h1 class="ui yellow header">
        Acc #<?=$query['id']?> - <?=get_string_rank($query['rank'])?>      </h1>
      <div class="ui hidden divider"></div>
<div class="ui text container">
      </div>
      <div class="ui hidden divider"></div>
<div class="ui hidden divider"></div>
			<div class="ui massive blue button"  onclick="alert_acc(<?=$query['id']?>);" style="width:60%;text-transform:uppercase;">Mua Ngay <?=number_format($query['gia'], 0, '.', '.')?> <sup>đ</sup></div>
      <div class="ui hidden divider"></div>
			 
	<div class="swiper-container sabner swiper-container-horizontal">
                    <div class="swiper-wrapper" style="transform: translate3d(0px, 0px, 0px); transition-duration: 0ms;">

			
<?php $image = explode("|",$query['hinhanh']); ?>
<?php foreach($image as $row): ?>
<div class="swiper-slide" style="width: 60%; margin-right: 5px;">
                                <a>
                                    <img style="width: 60%; border: 3px solid #948159;" src="<?=$row?>">
                                </a>
                            </div>
<?php endforeach; ?>											                            
											                    </div>
                    <div class="swiper-button-prev swiper-button-white swiper-button-disabled"></div>
                    <div class="swiper-button-next swiper-button-white"></div>
                    <div class="swiper-pagination swiper-pagination-clickable swiper-pagination-bullets"><span class="swiper-pagination-bullet swiper-pagination-bullet-active"></span><span class="swiper-pagination-bullet"></span><span class="swiper-pagination-bullet"></span><span class="swiper-pagination-bullet"></span></div>
                </div>
				<script>
	var mySwiper = new Swiper('.swiper-container', {
     preventClicks: false,
                paginationClickable: true,
                pagination: '.sabner .swiper-pagination',
                nextButton: '.sabner .swiper-button-next',
                prevButton: '.sabner .swiper-button-prev',
                spaceBetween: 5,
                centeredSlides: true,
                autoplay: 2500,
                autoplayDisableOnInteraction: false
});
	</script>		
		</div>    
		
  </div>


<div class="hr"></div>

<div class="ui container">


<div class="ui center aligned container">

      
      <div class="ui yellow statistic">
        <div class="value"><?=$query["count_skin"];?></div>
        <div class="label">Skins</div>
      </div>

      <div class="ui yellow statistic">
        <div class="value"><?=$query["count_champ"]?></div>
        <div class="label">Champs</div>
      </div>
      <div class="ui yellow statistic">
        <div class="value"><?=get_string_rank($query['rank'])?></div>
        <div class="label">Rank</div>
      </div>
    </div>


    <div class="ui grid">
      <div class="sixteen wide column">

                                    
			  </div>
        </div>


      </div> 

    </div> 
  </div>

<style>

.buttonfacebook {
    background-color: #3b5998;
    color: white;
    float: left;
    height: 50px;
    line-height: 50px;
    margin-left: 0;
    padding-left: 20px;
    position: relative;
    text-align: center;
    width: 200px;
}
	.buttoncall {
    background-color: #b8312f;
    color: white;
    float: left;
    height: 50px;
    line-height: 50px;
    margin-left: 0;
    padding-left: 20px;
    position: relative;
    text-align: center;
    width: 200px;
}
</style>






<script>

function muatructiep(){
    $('.small.modal')
  .modal('show');
}

$(document).ready(function() {

      // On input of the searchbar
    $("#account-skin-searchbar").on("input", function(){
      // Get the input of the searchbar, trim it and convert to lowercase
      var query = $.trim($("#account-skin-searchbar").val()).toLowerCase();

      // Loop all images
      $(".skin-search-image-id").each(function(){

        var $this = $(this);
        // Get current skinname from the alt tag, convert it and trim it
        var currentSkin = $.trim($(this).attr("alt")).toLowerCase();
        
        // If the input contains our skinname
        if(currentSkin.indexOf(query) === -1){
          $this.parent().addClass("skin-search-image");
        } else {
          $this.parent().removeClass("skin-search-image");
        }
      });
    });

});



</script>