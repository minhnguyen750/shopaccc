<div class="sa-mainsa">
    <div class="container">
        <div class="sa-logmain sa-themain">
            <div class="row">
                <div class="col-md-6">
                    <div class="sa-logbox">
                        <ul class="sa-lognav-tabs" role="tablist">
                            <li role="presentation" class="active"><a href="#nap-the" role="tab" data-toggle="tab">NẠP THẺ</a>
                            </li>
                        </ul>
                        <div class="sa-logtct tab-content">
                            <div role="tabpanel" class="tab-pane active" id="nap-the">
                                <div class="form-group">
                                    <label for="card_type_id">Loại thẻ:</label>



                                    <select class="form-control" name="card_type_id">
                                        <option value="VTT">Viettel</option>
                                        <option value="VMS">Mobiphone</option>
                                        <option value="VNP">Vinaphone</option>
                                        <option value="VNM">VNM</option>
                                        <option value="ZING">Zing</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="pin">Mã thẻ:</label>

                                    <input type="text" class="form-control" name="pin" />
                                </div>
                                <div class="form-group">
                                    <label for="seri">Seri:</label>
                                    <input type="text" class="form-control" name="seri" />
                                </div>
                                <div class="form-group">


                                    <button id="paycard" class="ui yellow inverted button" style="display:inline-block; width: 98%; height: 100%;">
                                        Nạp thẻ
                                    </button>
                                </div>


                                <img src="<?=$home?>/Content/images/thenap.png" width="100%" height="120%">

                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="sa-logbox">
                        <ul class="sa-lognav-tabs" role="tablist">
                            <li role="presentation" class="active"><a href="#luuY" role="tab" data-toggle="tab">LƯU Ý</a>
                            </li>
                        </ul>
                        <div class="sa-logtct tab-content">
                            <div role="tabpanel" class="tab-pane active" id="nap-the">
                                <div class="form-group" style="font-size: 17px;">
                                    <center>
                                    Tỉ lệ quy đổi: 1- 1<br>
                                    Ví dụ: Nạp thẻ Viettel 10.000 VNĐ sẽ nhận được 10.000 VNĐ tiền trong shop - Không mất phí.
                                <br>10.000 VNĐ Viettel = 10.000 VNĐ Tiền trong shop.
                                <br>Mọi thắc mắc xin liên hệ Admin Shop tại: Fb.com/Tuanduy.vo hoặc SĐT 0166.66.88.876
                                </center>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
