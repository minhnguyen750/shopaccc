
<?php
error_reporting(0);
ini_set('display_errors', 0);

   if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 

    session_start();
    ob_start();
    
    # Tiêu đề trang 
        $headtitle = 'Giới Thiệu';
    
    # Import Hệ thống
    require('core/database.php');
    require('core/head.php');

?>
        <div class="sa-mainsa">
    <div class="container">
        <div class="sa-lprod">
<div class="modal-body">
        <div class="sa-lpmain">

            <div class="sa-ttshop">
                <div style="text-align: center;">
                    <span style="font-size:36px;">
                        <span style="color:#FF0000;">
                            <strong>GIỚI THIỆU VỀ SHOPTHAIMINH.COM</strong>
                        </span>
                    </span>
                </div>

               <div>
                    <p><strong>ツ Chào mừng các bạn đến với ShopThaiMinh.Com. </strong></p>
                    <p class="c-feature-16-desc c-font-grey text-justify">Như các bạn đã biết, thị trường game ngày càng phong phú đa dạng, game online trở thành tâm điểm của mọi đối tượng. Thu hút số lượng lớn các game thủ trong mọi lứa tuổi, mọi quốc gia. Nhưng làm sao có được một account game như mong muốn, không mất nhiều thời gian và công sức khi chúng ta không có thời gian, không bị lừa đảo khi giao dịch. ShopThaiMinh.Com là một hệ thống mua bán nick game online tự động lớn nhất Việt Nam được ra đời nhằm tạo ra một sân chơi sử dụng công nghệ mới, dễ dàng sử dụng, an toàn và bảo mật. ShopThaiMinh.Com cung cấp số lượng lớn account với đa dạng game, phong phú cấp độ, đa dạng trường phái. Người chơi dễ dàng tìm cho mình một account như mong muốn, thanh toán tiện lợi, linh hoạt, nhanh chóng.</p>
                    <p class="c-feature-16-desc c-font-grey text-justify">ShopThaiMinh.Com ra đời đồng thời mang đến các giải pháp kinh doanh cho các đại lý và đáp ứng nhu cầu của game thủ theo tiêu chí hiện đại, an toàn, chất lượng.</p>
                    <p class="c-feature-16-desc c-font-grey text-justify">ShopThaiMinh.Com đã, đang và sẽ luôn là "Điểm đến an toàn dành cho game thủ" và sẽ tiếp tục cung cấp đầy đủ các account games mới cùng với chất lượng ngày càng tốt hơn.</p>
                    <div class="sa-ttshop">
                <div style="text-align: center;">
                    <span style="font-size:36px;">
                        <span style="color:#FF0000;">
                            <strong>HƯỚNG DẪN MUA ACC TẠI SHOPTHAIMINH.COM</strong>
                     <div class="sa-ttshop">
                <div style="text-align: center;">
                    <span style="font-size:36px;">
                        <span style="color:#FF0000;">
                          <div class="sa-lsnmain clearfix">
                    <div class="sa-ttshop">
                    
                        <div><span style="color:#ff6600;"><span style="font-size:25px;"><strong>Bước 1: Đăng nhập vào website (đăng nhập bằng Facebook)</strong></span></span><br>
                            <span style="font-size:25px;">* Nếu chưa có tài khoản Facebook, vui lòng <strong><a href="https://vi-vn.facebook.com/r.php"><span style="color:#66ff99;">đăng ký Facebook</span></a>
                            </strong></span>
                        </div>

                        <div style="text-align: center;"><img alt="" src="https://i.imgur.com/Frbyp17.png" style="text-align: center;"> <img alt="" src="https://i.imgur.com/uO0TcMo.png"></div>
                       

                        <div><br>
                            <strong><span style="font-size:25px;"><span style="color:#ff6600;">Bước 2: Nạp tiền vào tài khoản tại </span><span style="color:#F0FFF0;">&nbsp;</span><a href="https://shopthaiminh.com/nap-the/" target="_blank"><span style="color:#66ff99;">Đây</span></a><span style="color:#00ccff;">&nbsp;</span></span></strong><br>
                            <span style="font-size:25px;">Nhận các loại thẻ: Viettel, Mobi, Vina  ...<br>
<span style="color:#ff6600;">* Nạp tiền qua ngân hàng sẽ khuyến mại thêm 20% giá trị nạp</span></span><br> &nbsp;
                        </div>

                        <div style="text-align: center;"><img alt="" src="https://i.imgur.com/g9MZjEC.png" style=""></div>

                        <div><br>
                            <span style="color:#ff6600;"><strong><span style="font-size:25px;">Bước 3: Chọn acc và ấn "<span style="color:#66ff99;">Mua Ngay</span>" để hoàn tất giao dịch</span></strong>
                            </span>
                            <br> &nbsp;
                        </div>
                        <div style="text-align: center;"><img alt="" src="https://i.imgur.com/tDDfbwd.png" style="text-align: center; "><img alt="" src="https://i.imgur.com/DtN7eOu.png"></div>
                        <div><br>
                            <span style="font-size:25px;"><strong><span style="color:#ff6600;">Bước 4: Sau khi giao dịch hoàn tất, các bạn vui lòng vào trang</span><span style="color:#66ff99;"> </span><a href="https://shopthaiminh.com/lich-su-mua/"><span style="color:#66ff99;">Tài Khoản Đã Mua</span></a><span style="color:#0099ff;">&nbsp;</span><span style="color:#ff6600;">để lấy tài khoản và mật khẩu.</span></strong>
                            </span><br> &nbsp;
                        </div>

                        <div style="text-align: center;"><img alt="" src="https://i.imgur.com/yuAXILF.png" style="width: 700px; height: 508px;"></div><br>

                        <div style="text-align: center;"><strong><span style="font-size:30px;"><span style="color:#ff6600;">Mua xong các bạn vui lòng vào </span><a href="https://sso.garena.com/ui/login?app_id=10100&redirect_uri=https%3A%2F%2Faccount.garena.com%2F&locale=vi-VN"><span style="color:#66ff99;">bài này</span></a><span style="color:#ff6600;">&nbsp;để kích hoạt Email và SĐT nhé!</span></span></strong></div>

                    </div>
                </div>   </div>
                                         </div>
                                         </div>
                                          <p class="c-feature-16-desc c-font-grey text-justify">Mọi Chi Tiết Xin Liên Hệ : </p>
 <p class="c-feature-16-desc c-font-grey text-justify">Hotline : 0901.534.535</p>
 <p class="c-feature-16-desc c-font-grey text-justify">FB : Fb.com/shopthaiminh</p> 
                        </span>
                    </span>
                    
                    <p class="c-feature-16-desc c-font-grey text-right">
                        

</div>
     </div>
        </div>
    </div>
</div>
</div>
</div>
<?php require('core/foot.php');?>