<?php
error_reporting(0);
ini_set('display_errors', 0);

   if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 

     /*
Đăng ký kênh Học Viện Game nha
Để nhận hỗ trợ code nha
Link: https://youtube.com/c/hocviengame

     */
    session_start();
    ob_start();
    
    # Tiêu đề trang 
        $headtitle = 'Shop Liên Quân - Shop Mua Bán Acc Liên Quân Mobile Giá Rẻ Uy Tín Hàng Đầu VN - ShopThaiMinh.Com';
    
    # Import Hệ thống
    require('core/database.php');
    require('core/head.php');
    require('core/lienquan.php');
    require('core/foot.php');

?>
