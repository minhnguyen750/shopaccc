<?php

     /*
Đăng ký kênh Học Viện Game nha
Để nhận hỗ trợ code nha
Link: https://youtube.com/c/hocviengame

     */

    # khai báo sử dụng session
    session_start();

    # Import Hệ thống
    require('core/database.php');
    require('core/fbconfig.php');


$helper = $fb->getRedirectLoginHelper();


try {
$accessToken = $helper->getAccessToken("https://shopacc11.tk");


} catch(Facebook\Exceptions\FacebookResponseException $e) {
  // When Graph returns an error
  //echo 'Graph returned an error: ' . $e->getMessage();
} catch(Facebook\Exceptions\FacebookSDKException $e) {
  // When validation fails or other local issues
  //echo 'Facebook SDK returned an error: ' . $e->getMessage();
}
 
if (isset($accessToken)) {
  // Logged in!

$_SESSION['facebook_access_token'] = (string) $accessToken;

$response = $fb->get('/me?fields=id,name,email', $accessToken);

$name = $response->getGraphUser()['name'];
$email = $response->getGraphUser()['email'];
$fb_ID = $response->getGraphUser()['id'];

$_SESSION['username'] = $fb_ID;


$check = mysql_query("select * from `nguoidung` where `uid` = '$fb_ID'");
$check_number = mysql_num_rows($check);

if($check_number == 0){
//Lưu tài khoản vào Database rồi đăng nhập
mysql_query("INSERT INTO nguoidung (uid,hovaten,email,cash,admin) VALUES ('$fb_ID','".addslashes($name)."','$email','0','0')");
//Tiến hành đăng nhập khi đã lưu data
                          
}


} elseif ($helper->getError()) {
  // The user denied the request
}
header('Location: /index.php');