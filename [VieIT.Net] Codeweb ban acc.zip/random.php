<?php 

    /*
     * @ Code web bán nick LMHT được viết bởi Hậu Nguyễn
     *
     * @ Liên hệ: https://www.facebook.com/profile.php?id=100004684695399
     *
     */

    # Import Hệ thống
    require('core/database.php');

    # Hàm get ID

    if(isset($_GET['id']) && is_numeric($_GET['id']))
    {
    $id = addslashes($_GET['id']); // lấy id
    }

    # mấy cái biến vớ vẫn blablabla

    $not = mysql_result(mysql_query("SELECT COUNT(*) FROM `baidang` WHERE `id` = '$id'"), 0);
    $query = mysql_fetch_array(mysql_query("SELECT * FROM `baidang` WHERE `id` = '$id'"));

    switch ($_GET['act']) {
        
        default:
            $headtitle = 'Tài khoản LQMB #'.$id.'';
            include('core/head.php');
            require('core/random_lq.php');
            include('core/foot.php');
        break;
    }


?>