<?php 

    /*
     * @ Code web bán nick LMHT được viết bởi Dân Trần
     *
     * @ Liên hệ: https://www.facebook.com/EoCoWall.dz - 0963639070 (SMS Only)
     *
     */

    # khai báo sử dụng session
    session_start();

    # Import Hệ thống
    require('../core/database.php');

    # Hàm get ID


    if(isset($_POST['id']) && is_numeric($_POST['id']))
    {
    $id = addslashes($_POST['id']); // lấy id
    }else{exit;}
    

    # mấy cái biến vớ vẫn blablabla

    $not = mysql_result(mysql_query("SELECT COUNT(*) FROM `baidang` WHERE `id` = '$id'"), 0);
    $query = mysql_fetch_array(mysql_query("SELECT * FROM `baidang` WHERE `id` = '$id'"));

    # phần điều kiện mua acc

    if (!isset($uid)){
    $arr = array('error' => 1, 'msg' => 'Bạn chưa đăng nhập.', 'link' => 'login.php');
    }elseif($data['ban'] > 0){
    $arr = array('error' => 1, 'msg' => 'Tài khoản của bạn đã bị cấm trên hệ thống', 'link' => '');      
    }elseif($query['trangthai']=='off'){
    $arr = array('error' => 1, 'msg' => 'Tài khoản này đã được mua bởi người khác :(', 'link' => '');       
    }elseif($query['kichhoat']=='no'){
    $arr = array('error' => 1, 'msg' => 'Tài khoản này chưa được kích hoạt bán', 'link' => '');       
    }elseif($not==0){
    $arr = array('error' => 1, 'msg' => 'Tài khoản này không tồn tại', 'link' => '');       
    }elseif($data['cash'] < $query['gia']){
    $arr = array('error' => 1, 'msg' => 'Bạn không đủ tiền trong tài khoản, hãy nạp thêm.', 'link' => '');      
    }else{
    
    $datamsg = "Giao dịch thành công ! <br><span style=\"color:blue\"> Tài khoản : <b style=\"color:red\">  ".$query['taikhoan']."</b> mật khẩu :<b style=\"color:red\">   ".$query['matkhau']."</b>
  <hr style=\" color: red \">
    </span><br>● Cảm ơn bạn đã mua acc từ Shop chúng tôi ! Vui F5 để load lại <b style=\"color:red\"> Trang </b></a> Để Trở Lại Trang Chủ Mua Acc Tiếp Hoặc F5 ?<br>● Bạn vui lòng xem <a href=\"/bao-mat-tai-khoan/\" target=\"_blank\"> <b style=\"color:red\"> HƯỚNG DẪN BẢO MẬT NICK </b></a> . Nếu không làm theo bị mất nick bên mình không chịu trách nhiệm !<hr>● Mọi thắc mắc vui lòng liên hệ <a href=\"https://www.facebook.com/shopthaiminh\" target=\"_blank\"> <b style=\"color:red\"> Admin </b><hr>";


    $arr = array('error' => 0, 'msg' => $datamsg, 'link' => ''); 

    # Thêm vào data
    mysql_query("INSERT INTO lichsumua (uid,loainick,idacc,name,taikhoan,matkhau,price,date) VALUES ('".$uid."','".$query['loainick']."','".$id."','".addslashes($data['hovaten'])."','".$query['taikhoan']."','".$query['matkhau']."','".$query['gia']."','".date("H:i Y-m-d")."')");

    # Thay đổi trạng thái và trừ tiền
    mysql_query("UPDATE `nguoidung` SET `cash` = `cash` - '".$query['gia']."' where `uid`='".$uid."'");
    mysql_query("UPDATE `baidang` SET `trangthai` = 'off' where `id`='".$id."'");   
    }
    echo json_encode($arr);

?>
