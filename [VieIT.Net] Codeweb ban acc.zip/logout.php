<?php 

    /*
     * @ Code web bán nick LMHT được viết bởi Hậu Nguyễn
     *
     * @ Liên hệ: https://www.facebook.com/profile.php?id=100004684695399
     *
     */

    session_start();
    session_unset();
 
    if (isset($_SESSION['username'])){
        unset($_SESSION['username']);
    }
    header("Location: /index.php"); 
?>