<?php

    /*
     * @ Code web bán nick LMHT được viết bởi Hậu Nguyễn
     *
     * @ Liên hệ: https://www.facebook.com/profile.php?id=100004684695399
     *
     */
    session_start();
    ob_start();
    
    # Tiêu đề trang 
        $headtitle = 'Nạp Thẻ';
    
    # Import Hệ thống
    require('core/database.php');
    require('core/head.php');
    require('core/napthe-banthe.php');
    require('core/foot.php');

?>
