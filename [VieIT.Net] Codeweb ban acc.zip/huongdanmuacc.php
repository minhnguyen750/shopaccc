<?php
    /*
     * @ Code web bán nick LMHT được viết bởi Hậu Nguyễn
     *
     * @ Liên hệ: https://www.facebook.com/profile.php?id=100004684695399
     *
     */
	# Khai báo sử dụng session
	session_start();
	ob_start();

	# Tiêu đề trang 
	$headtitle = 'Lịch sử giao dịch';
	
	# Check quyền

	# Import Hệ thống
	require('core/head.php');
	require('core/huongdanmuacc.php');
	require('core/foot.php');

?>
