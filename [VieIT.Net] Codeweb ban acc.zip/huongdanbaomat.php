<?php

   
    session_start();
    ob_start();
    
    # Tiêu đề trang 
        $headtitle = 'Hướng dẫn bảo mật tài khoản';
    
    # Import Hệ thống
    require('core/database.php');
    require('core/head.php');
    require('core/huongdanbaomat.php');
    require('core/foot.php');

?>
