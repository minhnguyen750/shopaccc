<?php

//error_reporting(E_ALL);
//ini_set('display_errors', 1);
//Code by xuandung38



@ob_start();
require_once('../../../core/database.php');

if (!isset($_SESSION['username'])){
    echo json_encode(array('title' => "Lỗi", 'status' => error, 'msg' => "Bạn chưa đăng nhập ! Vui lòng đăng nhập để nạp thẻ !"));
    exit();
}

include 'GB_API.php';

//Lấy thông tin từ Gamebank tại https://sv.gamebank.vn/user/tich-hop-the-cao
$merchant_id = 33176; // interger
$api_user = "5800b2b3ed055"; // string
$api_password = "219e89e8a47768fa7de41183843c2cab"; // string




// truyen du lieu the

$username = $data['hovaten'];
$card_type = !empty($_POST['card_type_id']) ? addslashes(mysql_escape_string($_POST['card_type_id'])) : ""; // interger
$pin = !empty($_POST['pin']) ? addslashes(mysql_escape_string($_POST['pin'])) : ""; // string
$seri = !empty($_POST['seri']) ? addslashes(mysql_escape_string($_POST['seri'])) : ""; // string
$ma_bao_mat = !empty($_POST['ma_bao_mat']) ? addslashes(mysql_escape_string($_POST['ma_bao_mat'])) : "";


/**
 * Card_type = 1 => Viettel
 * Card_type = 2 => Mobiphone
 * Card_type = 3 => Vinaphone
 * Card_type = 4 => FPT
 * Card_type = 5 => VTC
 * 
**/


$gb_api = new GB_API();
$gb_api->setMerchantId($merchant_id);
$gb_api->setApiUser($api_user);
$gb_api->setApiPassword($api_password);
$gb_api->setPin($pin);
$gb_api->setSeri($seri);
$gb_api->setCardType(intval($card_type));
$gb_api->setNote($username); // ghi chu giao dich ben ban tu sinh
$gb_api->cardCharging();
$code = intval($gb_api->getCode());
$info_card = intval($gb_api->getInfoCard());

// nap the thanh cong
if($code === 0 && $info_card >= 10000) {
   echo json_encode(array('title' => "Nạp thẻ thành công", 'status' => info, 'msg' => "Nạp thẻ thành công mệnh giá". $info_card ));

    mysql_query("UPDATE `nguoidung` SET `cash` = `cash` + '".$info_card."' where `uid`='".$data['uid']."'");
    

    mysql_query("INSERT INTO lichsunap (uid,name,loaithe,serial,mathe,menhgia,date) VALUES ('".$data['uid']."','".addslashes($data['hovaten'])."','".$card_type."','".$seri."','".$pin."','".$info_card."','".date("H:i Y-m-d")."')");

if (mysql_num_rows(mysql_query("SELECT uid FROM top WHERE uid='".$data['uid']."'")) > 0)
{
mysql_query("UPDATE `top` SET `ucash` = `ucash` + '".$info_card."' where `uid`='".$data['uid']."'");
}else{
mysql_query("INSERT INTO top (uname,uid,ucash) VALUES ('".$data['hovaten']."','".$data['uid']."','".$info_card."')");
}


 
}
else {
    // get thong bao loi
   
    echo json_encode(array('title' => "Lỗi", 'status' => error, 'msg' =>$gb_api->getMsg()));
    
}


?>