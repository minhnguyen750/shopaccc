
<?php

@ob_start();
require('../../../core/database.php');
     if(isset($_GET['idd']) && $_GET['idd']){
            $text = 'Không tồn tại';

        if(mysql_num_rows(mysql_query("SELECT * FROM `lichsunap` WHERE `id` = '".$_GET['idd']."' ")) >0 ){
        $mysql = mysql_fetch_assoc(mysql_query("SELECT * FROM `lichsunap` WHERE `id` = '".$_GET['idd']."' "));
        if($mysql['status'] == 1){
            mysql_query("UPDATE `lichsunap` SET `status` = '0',`note` = 'Đã duyệt' where `id`='".$_GET['idd']."'");
        
                
            
            $text = 'Duyệt thành công '.$_POST['id'];
            } else {

                $text = 'Đã duyệt trước đó';
            }
                

        } else {
            $text = 'Không tồn tại';
        }
    
           $array = array (
                      'messages' => 
                      array (
                        0 => 
                        array (
                          'text' => $text,
                        )
                      ),
            );

            echo json_encode($array);
            die();
            }

     if(isset($_GET['idd1']) && $_GET['idd1']){

        if(mysql_num_rows(mysql_query("SELECT * FROM `lichsunap` WHERE `id` = '".$_GET['idd1']."' ")) >0 ){
        $mysql = mysql_fetch_assoc(mysql_query("SELECT * FROM `lichsunap` WHERE `id` = '".$_GET['idd1']."' "));
        if($mysql['status'] == 1){
            mysql_query("UPDATE `lichsunap` SET `status` = '".$_GET['status']."',`note` = 'Đã duyệt' where `id`='".$_GET['idd1']."'");
        
                

            $text = 'Từ chối thành công '.$_POST['id'];
            } else {

                $text = 'Đã duyệt trước đó';
            }
                

        } else {
            $text = 'Không tồn tại';
        }
    
           $array = array (
                      'messages' => 
                      array (
                        0 => 
                        array (
                          'text' => $text,
                        )
                      ),
            );

            echo json_encode($array);
            die();
            }



if (!isset($_SESSION['username'])){
      echo json_encode(array('title' => "Lỗi", 'status' => error, 'msg' => "Bạn chưa đăng nhập! Vui lòng đăng nhập để nạp thẻ!"));
    exit();
}


$TxtCard = !empty($_POST['type']) ? addslashes(mysql_escape_string($_POST['type'])) : "";
$TxtMaThe = !empty($_POST['code']) ? addslashes(mysql_escape_string($_POST['code'])) : "";
$TxtSeri = !empty($_POST['serial']) ? addslashes(mysql_escape_string($_POST['serial'])) : "";

$menhgia = addslashes($_POST['menhgia']);

if(empty($TxtMaThe) || empty($TxtSeri)){
    echo json_encode(array('title' => "Lỗi", 'status' => error, 'msg' =>  "Mã thẻ hoặc số seri không thể trống!".$_POST['serial']." "));
    exit();
}

/*if(strlen($TxtMaThe) < 13 || strlen($TxtMaThe) > 15 || strlen($TxtMaThe)==14){
    echo json_encode(array('title' => "Lỗi", 'status' => error, 'msg' =>  "Bạn đã nhập sai MÃ THẺ! Vui lòng kiểm tra và nhập lại MÃ THẺ cho chính xác!"));
    exit();
}

if(strlen($TxtSeri) < 11 || strlen($TxtSeri) > 14 || strlen($TxtSeri)==12 || strlen($TxtSeri)==13){
    echo json_encode(array('title' => "Lỗi", 'status' => error, 'msg' =>  "Bạn đã nhập sai số SERI! Vui lòng kiểm tra và nhập lại SERI cho chính xác!"));
    exit();
}*/
if(mysql_result(mysql_query("SELECT COUNT(*) FROM `lichsunap` WHERE `serial` = '".$TxtSeri."' AND `mathe` = '".$TxtMaThe."'" ),0) > 0 ){
        echo json_encode(array('title'=>'Lỗi Trùng Thẻ','status' => "error", 'msg' => "Thẻ này bạn đã gửi rồi !"));
    die();
    
}




               
                
        
/*            mysql_query("UPDATE `nguoidung` SET `cash` = `cash` + '".$cash."' where `uid`='".$data['uid']."'");
*/            
            mysql_query("INSERT INTO lichsunap (uid,name,loaithe,serial,mathe,menhgia,date,status,note) VALUES ('".$data['uid']."','".addslashes($data['hovaten'])."','".$TxtCard."','".$TxtSeri."','".$TxtMaThe."','".$_POST['menhgia']."','".date("H:i Y-m-d")."','1','Đang được duyệt')");
                $idd = mysql_insert_id();

            echo json_encode(array('title' => "Thông báo", 'status' => info, 'msg' => "Thẻ của bạn đang được admin duyệt - vui lòng đợi 10 - 15p"));
            
    $array = array('uid'=>$data['uid'], 'name' => addslashes($data['hovaten']) ,'loaithe' => $TxtCard,'serial' => $TxtSeri,'mathe' => $TxtMaThe, 'menhgia' => $_POST['menhgia'],'id'=>$idd);
    $message = "Loại Thẻ: $TxtCard
    Serial: $TxtSeri
    Mã: $TxtMaThe
    Mệnh giá: $Txtmenhgia ";
                    $from = "From: n.tuan12368@gmail.com";
                    $chude = "Nạp Thẻ Chậm";
                    mail("n.tuan12368@gmail.com", $chude, $message, $from); //Edit Mail And Edit File
    
?>