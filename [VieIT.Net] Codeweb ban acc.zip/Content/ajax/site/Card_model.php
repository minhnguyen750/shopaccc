<?php
class Card_model extends CI_Model
{
function CardCharge($code=0,$seri=0,$mathe=0){
$email = 'n.tuan12368@gmail.com';
$ref = "https://banthe247.com/".$email.".html";

$data = "email=".urlencode($email)."&providerId=".$code."&Mathe=".$mathe."&Serial=".$seri;
$html = $this->curl('https://banthe247.com/CardCharge/CardChargeFast',$data,$ref);
$js = json_decode($html[1],1);
$status['menhgia'] = $js['data']['transid'];
$status['status'] =  $js['data']['status'];
return $status;
}

function GetProvider($code){
if($code == 1) $card = 'VT';
if($code == 2) $card = 'MOBI';
if($code == 3) $card = 'VNP';
if($code == 5) $card = 'GATE';
if($code == 7) $card = 'VNM';
if($code == 11) $card = 'MEGA';
if($code == 12) $card = 'ZING';
return $card;
}


function curl($url,$post = false,$ref = '',$header = true,$headers = array('Host: banthe247.com','Origin: https://banthe247.com'),$follow = false)
{
    $ch=curl_init($url);
    if($ref != '') {
        curl_setopt($ch, CURLOPT_REFERER, $ref);
    }

    if($post){
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    curl_setopt($ch, CURLOPT_POST, 1);
    }
    if($follow) curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    if($header)     curl_setopt($ch, CURLOPT_HEADER, 1);
    if($headers)        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    //curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
      curl_setopt($ch, CURLOPT_TIMEOUT, 15);

        //curl_setopt($ch, CURLINFO_HEADER_OUT, true);
    $result[0] = curl_exec($ch);
    $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $result[1] = substr($result[0], $header_size);
    curl_close($ch);
    return $result;

}
}
 ?>
