<?php
session_start();


include 'Vippay_API.php';
require('../../../core/database.php');

// lay thong tin tu vippay - muc tich hop website trong quan ly tai khoan
$merchant_id = 7598; // interger
$api_user = "8a1e096d54a544b3bea9f3342997e8c7"; // string
$api_password = "25da93840f3246649a0cd585713058b4"; // string

// truyen du lieu the
$pin = $_POST['pin']; // string
$seri = $_POST['seri']; // string
$card_type = $_POST['card_type_id']; // interger
$ma_bao_mat = $_POST['ma_bao_mat'];

/**
 * Card_type = 1 => Viettel
 * Card_type = 2 => Mobiphone
 * Card_type = 3 => Vinaphone
 * Card_type = 4 => Gate
 * Card_type = 5 => VTC
 * Card_type = 10 => Vietnammobi
 * Card_type = 11 => Zing
 * Card_type = 14 => OnCash
 * 
**/

$card = "";
if($card_type == 1){
    $card = "Viettel";
}
else if($card_type == 2){
    $card = "Mobiphone";
}
else if($card_type == 3){
    $card = "Vinaphone";
}
else if($card_type == 5){
    $card = "VTC-Vcoin";
}
else if($card_type == 10){
    $card = "Vietnammobile";
}
else if($card_type == 11){
    $card = "Zing";
}
else if($card_type == 14){
    $card = "OnCash";
}

if($pin == null || $pin == "" || $seri == null || $seri == ""){
    echo json_encode(array('code' => 1, 'msg' => "Mã thẻ hoặc số seri không thể trống."));
    exit();
}
if(strlen($pin) < 8 || strlen($seri) < 8 || strlen($pin) > 20 || strlen($seri) > 20){
    echo json_encode(array('code' => 1, 'msg' => "Độ dài mã thẻ hoặc số seri không hợp lệ."));
    exit();
}
if (!isset($_SESSION['username'])){
    echo json_encode(array('code' => 1, 'msg' => "Chưa đăng nhập"));
    exit();
}
$vippay_api = new Vippay_API();
$vippay_api->setMerchantId($merchant_id);
$vippay_api->setApiUser($api_user);
$vippay_api->setApiPassword($api_password);
$vippay_api->setPin($pin);
$vippay_api->setSeri($seri);
$vippay_api->setCardType(intval($card_type));
$vippay_api->setNote("");  // Ghi chu cua ban
$vippay_api->cardCharging();
$code = intval($vippay_api->getCode());
$info_card = intval($vippay_api->getInfoCard());
$error = $vippay_api->getMsg();


// nap the thanh cong
if($code === 0 && $info_card >= 10000) {
    echo json_encode(array('code' => 0, 'msg' => "Nạp thẻ ".$card." thành công với mệnh giá " . $info_card. " vnđ."));

    mysql_query("UPDATE `nguoidung` SET `cash` = `cash` + '".$info_card."' where `uid`='".$data['uid']."'");
    
    mysql_query("INSERT INTO lichsunap (uid,name,loaithe,serial,mathe,menhgia,date) VALUES ('".$data['uid']."','".addslashes($data['hovaten'])."','".$card."','".$seri."','".$pin."','".$info_card."','".date("H:i Y-m-d")."')");
echo json_encode(array('err' => 0, 'msg' =>"Nạp thẻ thành công"));

// top nạp thẻ
if (mysql_num_rows(mysql_query("SELECT uid FROM top WHERE uid='".$data['uid']."'")) > 0)
{
mysql_query("UPDATE `top` SET `ucash` = `ucash` + '".$info_card."' where `uid`='".$data['uid']."'");
}else{
mysql_query("INSERT INTO top (uname,uid,ucash) VALUES ('".$data['hovaten']."','".$data['uid']."','".$info_card."')");
}



}
else {
    // get thong bao loi
    echo json_encode(array('code' => 1, 'msg' =>"Nạp thẻ ".$card." không thành công."));
}