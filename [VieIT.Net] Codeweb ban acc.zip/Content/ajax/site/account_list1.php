<?php
//error_reporting(E_ALL);
//ini_set('display_errors', 1);
    /*
     * @ Không xóa dòng này nếu bạn thông minh :D
     *
     * @ Code web bán nick LMHT được viết bởi An Thiên
     *
     * @ Liên hệ: https://www.facebook.com/HieuCMS
     *
     */
        
require_once('../../../core/database.php');

$skin_str = !empty($_POST['skin_str']) ? addslashes($_POST['skin_str']) : 0;
$champs_str = !empty($_POST['champ_str']) ? addslashes($_POST['champ_str']) : 0;
$rank = !empty($_POST['rank']) ? addslashes($_POST['rank']) : "";
$frame = !empty($_POST['frame']) ? addslashes($_POST['frame']) : "";
$order = !empty($_POST['order']) ? addslashes($_POST['order']) : 0; // tuong nhieu nhat
$price = !empty($_POST['price']) ? addslashes($_POST['price']) : ""; // theo tien


/*
$skin_str = !empty($_GET['skin_str']) ? addslashes($_GET['skin_str']) : 0;
$champs_str = !empty($_GET['champ_str']) ? addslashes($_GET['champ_str']) : 0;
$rank = !empty($_GET['rank']) ? addslashes($_GET['rank']) : 0;
$frame = !empty($_GET['frame']) ? addslashes($_GET['frame']) : 0;
$order = !empty($_GET['order']) ? addslashes($_GET['order']) : 0; // tuong nhieu nhat
$price = !empty($_GET['price']) ? addslashes($_GET['price']) : 0; // theo tien
*/

/* lọc theo tiền */
if($price == '1'):
$sql_gia = " gia <= 50000 AND ";
elseif($price == '2'):
$sql_gia = " gia BETWEEN 50000 AND 100000 AND ";
elseif($price == '3'):
$sql_gia = " gia BETWEEN 100000 AND 300000 AND ";
elseif($price == '4'):
$sql_gia = " gia BETWEEN 300000 AND 500000 AND ";
elseif($price == '5'):
$sql_gia = " gia BETWEEN 500000 AND 700000 AND ";
elseif($price == '6'):
$sql_gia = " gia BETWEEN 700000 AND 1000000 AND ";
elseif($price == '7'):
$sql_gia = " gia > 1000000 AND ";
elseif($price == '8'):
$sql_gia = " gia BETWEEN 105000 AND 300000 AND ";
elseif($price == '9'):
$sql_gia = " gia > 305000 AND ";
else:
$sql_gia = "";
endif;

/* rank */
switch ($rank) {
	case '1': // 
   	$sql_rank = "";
	break;
	case '2': // đồng
   $sql_rank = "rank BETWEEN 2 AND 6 AND ";
	break;
	case '3': // bạc
   $sql_rank = "rank BETWEEN 7 AND 11 AND ";
	break;
	case '4': // vàng
   $sql_rank = "rank BETWEEN 12 AND 16 AND ";
	break;
	case '5': // bk
   $sql_rank = "rank BETWEEN 17 AND 21 AND ";
	break;
	case '6': // kc
   $sql_rank = "rank BETWEEN 22 AND 26 AND ";
	break;
	case '7': // ct
   	$sql_rank = "rank BETWEEN 27 AND 27 AND";
	break;
	case '8': // td
   	$sql_rank = "rank BETWEEN 28 AND 28 AND";
	break;
	default:
   	$sql_rank = "";
	break;
}

/* khung */

if($frame==0){
$sql_khung = "khung = 0 AND ";
}elseif($frame > 1){
$sql_khung = "khung = ($frame-1) AND ";
}else{
$sql_khung = "";
}
if(!empty($champs_str) and empty($skin_str)){// lọc theo tướng ko lọc skin
$sql_cands = "`champs` LIKE '%$champs_str%' AND";
}elseif(empty($champs_str) and !empty($skin_str)){ // lọc skin không lọc theo tướng
$sql_cands = "`skins` LIKE '%$skin_str%' AND";
}elseif(!empty($champs_str) and !empty($skin_str)){ // lọc cả 2
$sql_cands = "(`champs` LIKE '%$champs_str%' OR `skins` LIKE '%$skin_str%') AND";
}else{
$sql_cands = "";
}

/* config page */
if (isset($_POST["page"])) { $page  = $_POST["page"]; } else { $page=1; }; 
$num_rec_per_page=12;
$start_from = ($page-1) * $num_rec_per_page;  
$i=0; 

if (isset($_POST["order"]) && $_POST["order"]=='1'):// nhiều tướng

$result = mysql_query("SELECT * FROM `baidang` where $sql_cands $sql_gia $sql_rank $sql_khung `trangthai`!='off' AND `loainick` ='LQ' order by `count_champ` DESC LIMIT $start_from, $num_rec_per_page");
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `baidang` WHERE $sql_cands $sql_gia $sql_rank $sql_khung `trangthai`!='off' AND `loainick` ='LQ'"), 0);

elseif (isset($_POST["order"]) && $_POST["order"]=='2'):// nhiều skin

$result = mysql_query("SELECT * FROM `baidang` where $sql_cands $sql_gia $sql_rank $sql_khung `trangthai`!='off' AND `loainick` ='LQ' order by `count_skin` DESC LIMIT $start_from, $num_rec_per_page");
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `baidang` WHERE $sql_cands $sql_gia $sql_rank $sql_khung `trangthai`!='off' AND `loainick` ='LQ'"), 0);

else:// không lọc

$result = mysql_query("SELECT * FROM `baidang` where $sql_cands $sql_gia $sql_rank $sql_khung `trangthai`!='off' AND `loainick` ='LQ' order by time DESC LIMIT $start_from, $num_rec_per_page");
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `baidang` WHERE $sql_cands $sql_gia $sql_rank $sql_khung `trangthai`!='off' AND `loainick` ='LQ'"), 0);

endif;

$total_pages = ceil($tong / $num_rec_per_page);
if($tong > 0):
while ($row = mysql_fetch_array($result, MYSQL_ASSOC)): ?>


<div class="sa-lpcol">
                        <div class="sa-lpi" style="border-image: url(/assets/img/khung/diamond.png) 25 round;">                            <a class="sa-lpimg" href="/account/68">
                            </a><a class="sa-lpimg" href="/acc-<?=$row['id']?>">
                                 
                                <h3><span class="sa-lpcode">#<?=$row['id']?> - <?=get_string_rank($row['rank'])?></span></h3>
                                                                <p class="sa-lpping"><img src="<?=$row['thumb']?>">
                                </p>
                                                                    
                            <div class="sa-lpinfo">
                                <div class="sa-lpits mcustomscrollbar">

                                    <br>
                                    ● Rank: <?=get_string_rank($row['rank'])?><br>
                                    
                                                                        ● Tướng: <?=$row['count_champ']?><br>
                                    ● Trang Phục: <?=$row['count_bangngoc']?><br>
                                    ● Bảng Ngọc: <?=$row['count_bangngoc']?><br>
                                                            </div>
                                                          
                        </div>     
                                 

                            </a>
                            <div class="sa-lpbott clearfix">
                                                                    
                                <div class="gg-info">
                                    <div class="gg-lpbif"> <p class="hero"> Tướng: <?=$row['count_champ']?> <br> </p><p class="skin"> Skin: <?=$row['count_skin']?></p></div>
                                   
                                    <div class="gg-lpbpri"> <p class="hero"> Ngọc: <?=$row['count_bangngoc']?> <br> </p><p class="skin"> Giảm giá: 0% </p></div>
                                </div>
                                 
                                <div class="sa-lpbif" style="    text-align: left;">
                                                                        <p class="sa-lpbpice"><?=number_format($row['atm'], 0, '.', '.')?><sup>ATM</sup></p>

                                                                                                        
                                    <a href="/acc-<?=$row['id']?>" class="xem-acc" title="XEM ACC">XEM ACC</a>
                                                                    </div>

                                <div class="sa-lpbpri">
                                    <p class="sa-lpbpice"><?=number_format($row['gia'], 0, '.', '.')?><sup>CARD</sup></p>
                                    <p></p>
                                     
                                    <a id="button_mua" class="sa-lpbbtn ac-buy-acc" onclick="alert_acc(<?=$row['id']?>); return false;" class="sa-lpbbtn ac-buy-acc" title="MUA NGAY">MUA NGAY</a>
                                    
                                                                </div>
                            </div>
                        </div>
                    </div>
                                                       

<?php if($i==3):?>
<div class="clearfix"></div> 
<?php elseif($i==7):?>
<div class="clearfix"></div> 
<?php elseif($i==11):?>
<div class="clearfix"></div> 
<?php endif; ?>

<?php $i++;  endwhile; ?>


<div class="clearfix"></div>   </div>

<ul class="sa-pagging">
<li onclick="page=1;" class="PagedList-skipToFirst"><a href="?page=1">««</a></li>
<?php
for ($i=1; $i<=$total_pages; $i++) { 

if($_POST['page']==$i):
echo "<li onclick='page=$i;' class='active'><a href='?page=$i'>".$i."</a></li>";
else:
echo "<li onclick='page=$i;'><a href='?page=$i'>".$i."</a></li>";
endif;

}; 

?>
<li onclick="page=<?=$total_pages?>;" class="PagedList-skipToLast"><a href="?page=<?=$total_pages?>">»»</a></li>
</ul>
<?php else: ?>
<h3 class="text-center">Không Có Tài Khoản Nào Được Tìm Thấy</h3>
<?php endif; ?>