<?php
error_reporting(0);
ini_set('display_errors', 0);

   if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 

    /*
     * @ Code web bán nick LMHT được viết bởi Hậu Nguyễn
     *
     * @ Liên hệ: https://www.facebook.com/profile.php?id=100004684695399
     *
     */
    session_start();
    ob_start();
    
    # Tiêu đề trang 
        $headtitle = 'Shop Bán Acc Liên Quân Mobile - Giá Rẻ - Uy Tín - Chất Lượng';
    
    # Import Hệ thống
    require('core/database.php');
    require('core/head.php');
    require('core/uytin.php');
    require('core/foot.php');

?>
